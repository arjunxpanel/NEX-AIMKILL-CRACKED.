package com.api;

import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;

public class HWID
{
    private static final char[] hexArray;
    
    static {
        hexArray = "0123456789ABCDEF".toCharArray();
    }
    
    public static String bytesToHex(final byte[] array) {
        final char[] array2 = new char[array.length * 2];
        for (int i = 0; i < array.length; ++i) {
            final int n = array[i] & 0xFF;
            final char[] hexArray = HWID.hexArray;
            array2[i * 2] = hexArray[n >>> 4];
            array2[i * 2 + 1] = hexArray[n & 0xF];
        }
        return new String(array2);
    }
    
    public static byte[] generateHWID() {
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            final StringBuilder sb = new StringBuilder();
            sb.append(System.getProperty("os.name"));
            sb.append(System.getProperty("os.arch"));
            sb.append(System.getProperty("os.version"));
            sb.append(Runtime.getRuntime().availableProcessors());
            sb.append(System.getenv("PROCESSOR_IDENTIFIER"));
            sb.append(System.getenv("PROCESSOR_ARCHITECTURE"));
            sb.append(System.getenv("PROCESSOR_ARCHITEW6432"));
            sb.append(System.getenv("NUMBER_OF_PROCESSORS"));
            return instance.digest(sb.toString().getBytes());
        }
        catch (final NoSuchAlgorithmException ex) {
            throw new Error("Algorithm wasn't found.", (Throwable)ex);
        }
    }
    
    public static String getHWID() {
        return bytesToHex(generateHWID());
    }
    
    public static byte[] hexStringToByteArray(final String s) {
        final int length = s.length();
        final byte[] array = new byte[length / 2];
        for (int i = 0; i < length; i += 2) {
            array[i / 2] = (byte)((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
        }
        return array;
    }
}
