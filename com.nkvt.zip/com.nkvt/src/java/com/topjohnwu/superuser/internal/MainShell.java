package com.topjohnwu.superuser.internal;

import java.io.InputStream;
import com.topjohnwu.superuser.NoShellException;
import com.topjohnwu.superuser.Shell;
import java.util.concurrent.Executor;

public final class MainShell
{
    private static BuilderImpl defaultBuilder;
    private static boolean isInitMain;
    private static ShellImpl mainShell;
    
    private MainShell() {
    }
    
    public static ShellImpl get() {
        synchronized (MainShell.class) {
            ShellImpl shellImpl;
            if ((shellImpl = getCached()) == null) {
                MainShell.isInitMain = true;
                shellImpl = getBuilder().build();
                MainShell.isInitMain = false;
            }
            return shellImpl;
        }
    }
    
    public static void get(final Executor executor, final Shell.GetShellCallback getShellCallback) {
        final ShellImpl cached = getCached();
        if (cached != null) {
            if (executor == null) {
                getShellCallback.onShell(cached);
            }
            else {
                executor.execute((Runnable)new MainShell$$ExternalSyntheticLambda0(getShellCallback, cached));
            }
        }
        else {
            Shell.EXECUTOR.execute((Runnable)new MainShell$$ExternalSyntheticLambda2(executor, getShellCallback));
        }
    }
    
    private static BuilderImpl getBuilder() {
        if (MainShell.defaultBuilder == null) {
            MainShell.defaultBuilder = new BuilderImpl();
        }
        return MainShell.defaultBuilder;
    }
    
    public static ShellImpl getCached() {
        synchronized (MainShell.class) {
            final ShellImpl mainShell = MainShell.mainShell;
            if (mainShell != null && mainShell.getStatus() < 0) {
                MainShell.mainShell = null;
            }
            return MainShell.mainShell;
        }
    }
    
    public static Shell.Job newJob(final boolean b, final InputStream inputStream) {
        return new PendingJob(b).add(inputStream);
    }
    
    public static Shell.Job newJob(final boolean b, final String... array) {
        return new PendingJob(b).add(array);
    }
    
    static void set(final ShellImpl mainShell) {
        synchronized (MainShell.class) {
            if (MainShell.isInitMain) {
                MainShell.mainShell = mainShell;
            }
        }
    }
    
    public static void setBuilder(final Shell.Builder builder) {
        synchronized (MainShell.class) {
            MainShell.defaultBuilder = (BuilderImpl)builder;
        }
    }
}
