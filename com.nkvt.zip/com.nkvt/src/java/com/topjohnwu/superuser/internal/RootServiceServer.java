package com.topjohnwu.superuser.internal;

import com.topjohnwu.superuser.ipc.RootService;
import android.os.RemoteException;
import android.os.Message;
import android.os.Debug;
import android.os.Bundle;
import java.util.Iterator;
import java.util.Map$Entry;
import java.lang.reflect.Constructor;
import android.os.IBinder;
import android.content.Intent;
import java.io.File;
import java.util.HashMap;
import android.util.ArrayMap;
import android.os.Build$VERSION;
import com.topjohnwu.superuser.Shell;
import android.content.Context;
import android.os.FileObserver;
import android.os.Messenger;
import android.content.ComponentName;
import java.util.Map;
import android.os.IBinder$DeathRecipient;

public class RootServiceServer extends Stub implements IBinder$DeathRecipient
{
    private static RootServiceServer mInstance;
    private final Map<ComponentName, ServiceContainer> activeServices;
    private Messenger client;
    private boolean isDaemon;
    private String mAction;
    private final FileObserver observer;
    
    private RootServiceServer(final Context context) {
        boolean enableVerboseLogging = false;
        this.isDaemon = false;
        if (System.getenv("LIBSU_VERBOSE_LOGGING") != null) {
            enableVerboseLogging = true;
        }
        Shell.enableVerboseLogging = enableVerboseLogging;
        this.mAction = System.getenv("LIBSU_BROADCAST_ACTION");
        Utils.context = context;
        Object activeServices;
        if (Build$VERSION.SDK_INT >= 19) {
            activeServices = new ArrayMap();
        }
        else {
            activeServices = new HashMap();
        }
        this.activeServices = (Map<ComponentName, ServiceContainer>)activeServices;
        final AppObserver observer = new AppObserver(new File(context.getPackageCodePath()));
        this.observer = observer;
        this.broadcast();
        observer.startWatching();
    }
    
    private IBinder bindInternal(final Intent intent) throws Exception {
        final ComponentName component = intent.getComponent();
        ServiceContainer serviceContainer;
        if ((serviceContainer = (ServiceContainer)this.activeServices.get((Object)component)) == null) {
            final java.lang.reflect.Constructor<?> declaredConstructor = Class.forName(component.getClassName()).getDeclaredConstructor((Class<?>[])new Class[0]);
            declaredConstructor.setAccessible(true);
            RootServerMain.attachBaseContext.invoke(declaredConstructor.newInstance(new Object[0]), new Object[] { Utils.context });
            if ((serviceContainer = (ServiceContainer)this.activeServices.get((Object)component)) == null) {
                return null;
            }
        }
        if (serviceContainer.binder != null) {
            final StringBuilder sb = new StringBuilder();
            sb.append(component.getClassName());
            sb.append(" rebind");
            Utils.log("IPC", sb.toString());
            serviceContainer.service.onRebind(serviceContainer.intent);
        }
        else {
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(component.getClassName());
            sb2.append(" bind");
            Utils.log("IPC", sb2.toString());
            serviceContainer.binder = serviceContainer.service.onBind(intent);
            serviceContainer.intent = intent.cloneFilter();
        }
        return serviceContainer.binder;
    }
    
    public static RootServiceServer getInstance(final Context context) {
        if (RootServiceServer.mInstance == null) {
            RootServiceServer.mInstance = new RootServiceServer(context);
        }
        return RootServiceServer.mInstance;
    }
    
    private void setAsDaemon() {
        if (!this.isDaemon) {
            HiddenAPIs.addService(RootServerMain.getServiceName(Utils.context.getPackageName()), (IBinder)this);
            this.isDaemon = true;
        }
    }
    
    private void stopAllService(final boolean b) {
        final Iterator iterator = this.activeServices.entrySet().iterator();
        while (iterator.hasNext()) {
            final ServiceContainer serviceContainer = (ServiceContainer)((Map$Entry)iterator.next()).getValue();
            if (serviceContainer.service.onUnbind(serviceContainer.intent) && !b) {
                this.setAsDaemon();
            }
            else {
                serviceContainer.service.onDestroy();
                iterator.remove();
            }
        }
        if (b || this.activeServices.isEmpty()) {
            System.exit(0);
        }
    }
    
    private void stopService(final ComponentName componentName, final boolean b) {
        final ServiceContainer serviceContainer = (ServiceContainer)this.activeServices.get((Object)componentName);
        if (serviceContainer != null) {
            if (serviceContainer.service.onUnbind(serviceContainer.intent) && !b) {
                this.setAsDaemon();
            }
            else {
                serviceContainer.service.onDestroy();
                this.activeServices.remove((Object)componentName);
            }
        }
        if (this.activeServices.isEmpty()) {
            System.exit(0);
        }
    }
    
    public IBinder bind(final Intent intent) {
        final IBinder[] array = { null };
        UiThreadHandler.runAndWait((Runnable)new RootServiceServer$$ExternalSyntheticLambda4(this, array, intent));
        return array[0];
    }
    
    public void binderDied() {
        final Messenger client = this.client;
        this.client = null;
        if (client != null) {
            client.getBinder().unlinkToDeath((IBinder$DeathRecipient)this, 0);
        }
        UiThreadHandler.run((Runnable)new RootServiceServer$$ExternalSyntheticLambda0(this));
    }
    
    public void broadcast() {
        Utils.context.sendBroadcast(RootServiceManager.getBroadcastIntent(Utils.context, this.mAction, (IBinder)this));
    }
    
    public void connect(final Bundle bundle) {
        if (this.client != null) {
            return;
        }
        final IBinder binder = bundle.getBinder("binder");
        if (binder == null) {
            return;
        }
        try {
            binder.linkToDeath((IBinder$DeathRecipient)this, 0);
            final Messenger client = new Messenger(binder);
            if (bundle.getBoolean("debug", false)) {
                final StringBuilder sb = new StringBuilder();
                sb.append(Utils.context.getPackageName());
                sb.append(":root");
                HiddenAPIs.setAppName(sb.toString());
                Utils.log("IPC", "Waiting for debugger to be attached...");
                while (!Debug.isDebuggerConnected()) {
                    try {
                        Thread.sleep(200L);
                    }
                    catch (final InterruptedException ex) {}
                }
                Utils.log("IPC", "Debugger attached!");
            }
            final Message obtain = Message.obtain();
            obtain.what = 1;
            try {
                client.send(obtain);
                this.client = client;
            }
            catch (final RemoteException ex2) {}
        }
        catch (final RemoteException ex3) {
            Utils.err("IPC", (Throwable)ex3);
        }
    }
    
    public void register(final RootService service) {
        final ServiceContainer serviceContainer = new ServiceContainer();
        serviceContainer.service = service;
        this.activeServices.put((Object)service.getComponentName(), (Object)serviceContainer);
    }
    
    public void selfStop(final ComponentName componentName) {
        UiThreadHandler.run((Runnable)new RootServiceServer$$ExternalSyntheticLambda1(this, componentName));
    }
    
    public void setAction(final String mAction) {
        this.mAction = mAction;
    }
    
    public void stop(final ComponentName componentName) {
        UiThreadHandler.run((Runnable)new RootServiceServer$$ExternalSyntheticLambda2(this, componentName));
    }
    
    public void unbind(final ComponentName componentName) {
        UiThreadHandler.run((Runnable)new RootServiceServer$$ExternalSyntheticLambda3(this, componentName));
    }
    
    class AppObserver extends FileObserver
    {
        private final String name;
        final RootServiceServer this$0;
        
        AppObserver(final RootServiceServer this$0, final File file) {
            this.this$0 = this$0;
            super(file.getParent(), 1984);
            final StringBuilder sb = new StringBuilder();
            sb.append("Start monitoring: ");
            sb.append(file.getParent());
            Utils.log("IPC", sb.toString());
            this.name = file.getName();
        }
        
        public void onEvent(final int n, final String s) {
            if (n == 1024 || this.name.equals((Object)s)) {
                UiThreadHandler.run((Runnable)new RootServiceServer$AppObserver$$ExternalSyntheticLambda0(this));
            }
        }
    }
    
    static class ServiceContainer
    {
        IBinder binder;
        Intent intent;
        RootService service;
    }
}
