package com.nkvt;

import android.text.TextPaint;
import android.graphics.Typeface;
import android.text.style.MetricAffectingSpan;

public class CustomTypefaceSpan extends MetricAffectingSpan
{
    private final Typeface typeface;
    
    public CustomTypefaceSpan(final Typeface typeface) {
        this.typeface = typeface;
    }
    
    public void updateDrawState(final TextPaint textPaint) {
        textPaint.setTypeface(this.typeface);
    }
    
    public void updateMeasureState(final TextPaint textPaint) {
        textPaint.setTypeface(this.typeface);
    }
}
