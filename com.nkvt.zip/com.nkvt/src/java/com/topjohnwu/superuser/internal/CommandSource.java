package com.topjohnwu.superuser.internal;

import java.io.IOException;
import java.io.OutputStream;

class CommandSource implements ShellInputSource
{
    private final String[] cmd;
    
    CommandSource(final String[] cmd) {
        this.cmd = cmd;
    }
    
    @Override
    public void serve(final OutputStream outputStream) throws IOException {
        for (final String s : this.cmd) {
            outputStream.write(s.getBytes(Utils.UTF_8));
            outputStream.write(10);
            Utils.log("SHELL_IN", s);
        }
    }
}
