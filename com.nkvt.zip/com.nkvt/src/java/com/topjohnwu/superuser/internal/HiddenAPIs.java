package com.topjohnwu.superuser.internal;

import android.os.IBinder;
import android.os.Build$VERSION;
import android.content.Context;

class HiddenAPIs
{
    public static final int FLAG_RECEIVER_FROM_SHELL;
    private static Context systemContext;
    
    static {
        int flag_RECEIVER_FROM_SHELL;
        if (Build$VERSION.SDK_INT >= 26) {
            flag_RECEIVER_FROM_SHELL = 4194304;
        }
        else {
            flag_RECEIVER_FROM_SHELL = 0;
        }
        FLAG_RECEIVER_FROM_SHELL = flag_RECEIVER_FROM_SHELL;
    }
    
    static void addService(final String s, final IBinder binder) {
        try {
            RootServerMain.addService.invoke((Object)null, new Object[] { s, binder });
        }
        catch (final Exception ex) {
            Utils.err("IPC", (Throwable)ex);
        }
    }
    
    static IBinder getService(final String s) {
        try {
            return (IBinder)RootServerMain.getService.invoke((Object)null, new Object[] { s });
        }
        catch (final Exception ex) {
            Utils.err("IPC", (Throwable)ex);
            return null;
        }
    }
    
    static Context getSystemContext() {
        synchronized (HiddenAPIs.class) {
            if (HiddenAPIs.systemContext == null) {
                HiddenAPIs.systemContext = RootServerMain.getSystemContext();
            }
            return HiddenAPIs.systemContext;
        }
    }
    
    static void setAppName(final String s) {
        try {
            Class.forName("android.ddm.DdmHandleAppName").getDeclaredMethod("setAppName", String.class, Integer.TYPE).invoke((Object)null, new Object[] { s, 0 });
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
    }
}
