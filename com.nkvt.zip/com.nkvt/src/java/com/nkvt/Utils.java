package com.nkvt;

import android.util.TypedValue;
import android.content.Context;

public class Utils
{
    Context context;
    
    public Utils(final Context context) {
        this.context = context;
    }
    
    public int FixDP(final int n) {
        return (int)TypedValue.applyDimension(1, (float)n, this.context.getResources().getDisplayMetrics());
    }
}
