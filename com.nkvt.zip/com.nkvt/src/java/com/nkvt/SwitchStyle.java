package com.nkvt;

import android.view.View$OnLongClickListener;
import android.view.View$OnClickListener;
import android.view.MotionEvent;
import android.view.View$MeasureSpec;
import android.graphics.Color;
import android.content.res.TypedArray;
import android.graphics.Paint$Style;
import android.os.Build$VERSION;
import android.graphics.Canvas;
import android.util.TypedValue;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.animation.Animator;
import android.content.Context;
import android.animation.ValueAnimator;
import android.graphics.RectF;
import android.graphics.Paint;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator$AnimatorUpdateListener;
import android.animation.Animator$AnimatorListener;
import android.widget.Checkable;
import android.view.View;

public class SwitchStyle extends View implements Checkable
{
    private static final int DEFAULT_HEIGHT;
    private static final int DEFAULT_WIDTH;
    private final int ANIMATE_STATE_DRAGING;
    private final int ANIMATE_STATE_NONE;
    private final int ANIMATE_STATE_PENDING_DRAG;
    private final int ANIMATE_STATE_PENDING_RESET;
    private final int ANIMATE_STATE_PENDING_SETTLE;
    private final int ANIMATE_STATE_SWITCH;
    private ViewState afterState;
    private int animateState;
    private Animator$AnimatorListener animatorListener;
    private ValueAnimator$AnimatorUpdateListener animatorUpdateListener;
    private final ArgbEvaluator argbEvaluator;
    private int background;
    private ViewState beforeState;
    private int borderWidth;
    private float bottom;
    private boolean buttonEdgeFrame;
    private float buttonMaxX;
    private float buttonMinX;
    private Paint buttonPaint;
    private float buttonRadius;
    private float centerX;
    private float centerY;
    private int checkLineColor;
    private float checkLineLength;
    private int checkLineWidth;
    private int checkedButtonColor;
    private int checkedColor;
    private float checkedLineOffsetX;
    private float checkedLineOffsetY;
    private boolean enableEffect;
    private float height;
    private boolean isChecked;
    private boolean isEventBroadcast;
    private boolean isTouchingDown;
    private boolean isUiInited;
    private float left;
    private OnCheckedChangeListener onCheckedChangeListener;
    private Paint paint;
    private Runnable postPendingDrag;
    private RectF rect;
    private float right;
    private int shadowColor;
    private boolean shadowEffect;
    private int shadowOffset;
    private int shadowRadius;
    private boolean showIndicator;
    private float top;
    private long touchDownTime;
    private int uncheckButtonColor;
    private int uncheckCircleColor;
    private float uncheckCircleOffsetX;
    private float uncheckCircleRadius;
    private int uncheckCircleWidth;
    private int uncheckColor;
    private ValueAnimator valueAnimator;
    private float viewRadius;
    private ViewState viewState;
    private float width;
    
    static {
        DEFAULT_WIDTH = dp2pxInt(46.0f);
        DEFAULT_HEIGHT = dp2pxInt(25.0f);
    }
    
    public SwitchStyle(final Context context) {
        super(context);
        this.ANIMATE_STATE_NONE = 0;
        this.ANIMATE_STATE_PENDING_DRAG = 1;
        this.ANIMATE_STATE_DRAGING = 2;
        this.ANIMATE_STATE_PENDING_RESET = 3;
        this.ANIMATE_STATE_PENDING_SETTLE = 4;
        this.ANIMATE_STATE_SWITCH = 5;
        this.buttonEdgeFrame = true;
        this.rect = new RectF();
        this.animateState = 0;
        this.argbEvaluator = new ArgbEvaluator();
        this.isTouchingDown = false;
        this.isUiInited = false;
        this.isEventBroadcast = false;
        this.postPendingDrag = (Runnable)new Runnable() {
            final SwitchStyle this$0;
            
            public void run() {
                if (!this.this$0.isInAnimating()) {
                    this.this$0.pendingDragState();
                }
            }
        };
        this.animatorUpdateListener = (ValueAnimator$AnimatorUpdateListener)new ValueAnimator$AnimatorUpdateListener() {
            final SwitchStyle this$0;
            
            public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                final float floatValue = (float)valueAnimator.getAnimatedValue();
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1 && access$300 != 3 && access$300 != 4) {
                    if (access$300 == 5) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                        final float n = (this.this$0.viewState.buttonX - this.this$0.buttonMinX) / (this.this$0.buttonMaxX - this.this$0.buttonMinX);
                        this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)this.this$0.uncheckColor, (Object)this.this$0.checkedColor);
                        this.this$0.viewState.radius = this.this$0.viewRadius * n;
                        this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)0, (Object)this.this$0.checkLineColor);
                    }
                }
                else {
                    this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkedLineColor, (Object)this.this$0.afterState.checkedLineColor);
                    this.this$0.viewState.radius = this.this$0.beforeState.radius + (this.this$0.afterState.radius - this.this$0.beforeState.radius) * floatValue;
                    if (this.this$0.animateState != 1) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                    }
                    this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkStateColor, (Object)this.this$0.afterState.checkStateColor);
                }
                this.this$0.postInvalidate();
            }
        };
        this.animatorListener = (Animator$AnimatorListener)new Animator$AnimatorListener() {
            final SwitchStyle this$0;
            
            public void onAnimationCancel(final Animator animator) {
            }
            
            public void onAnimationEnd(final Animator animator) {
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1) {
                    if (access$300 != 3) {
                        if (access$300 != 4) {
                            if (access$300 == 5) {
                                final SwitchStyle this$0 = this.this$0;
                                this$0.isChecked ^= true;
                                this.this$0.animateState = 0;
                                this.this$0.postInvalidate();
                                this.this$0.broadcastEvent();
                            }
                        }
                        else {
                            this.this$0.animateState = 0;
                            this.this$0.postInvalidate();
                            this.this$0.broadcastEvent();
                        }
                    }
                    else {
                        this.this$0.animateState = 0;
                        this.this$0.postInvalidate();
                    }
                }
                else {
                    this.this$0.animateState = 2;
                    this.this$0.viewState.checkedLineColor = 0;
                    this.this$0.viewState.radius = this.this$0.viewRadius;
                    this.this$0.postInvalidate();
                }
            }
            
            public void onAnimationRepeat(final Animator animator) {
            }
            
            public void onAnimationStart(final Animator animator) {
            }
        };
        this.init(context, null);
    }
    
    public SwitchStyle(final Context context, final AttributeSet set) {
        super(context, set);
        this.ANIMATE_STATE_NONE = 0;
        this.ANIMATE_STATE_PENDING_DRAG = 1;
        this.ANIMATE_STATE_DRAGING = 2;
        this.ANIMATE_STATE_PENDING_RESET = 3;
        this.ANIMATE_STATE_PENDING_SETTLE = 4;
        this.ANIMATE_STATE_SWITCH = 5;
        this.buttonEdgeFrame = true;
        this.rect = new RectF();
        this.animateState = 0;
        this.argbEvaluator = new ArgbEvaluator();
        this.isTouchingDown = false;
        this.isUiInited = false;
        this.isEventBroadcast = false;
        this.postPendingDrag = (Runnable)new Runnable() {
            final SwitchStyle this$0;
            
            public void run() {
                if (!this.this$0.isInAnimating()) {
                    this.this$0.pendingDragState();
                }
            }
        };
        this.animatorUpdateListener = (ValueAnimator$AnimatorUpdateListener)new ValueAnimator$AnimatorUpdateListener() {
            final SwitchStyle this$0;
            
            public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                final float floatValue = (float)valueAnimator.getAnimatedValue();
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1 && access$300 != 3 && access$300 != 4) {
                    if (access$300 == 5) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                        final float n = (this.this$0.viewState.buttonX - this.this$0.buttonMinX) / (this.this$0.buttonMaxX - this.this$0.buttonMinX);
                        this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)this.this$0.uncheckColor, (Object)this.this$0.checkedColor);
                        this.this$0.viewState.radius = this.this$0.viewRadius * n;
                        this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)0, (Object)this.this$0.checkLineColor);
                    }
                }
                else {
                    this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkedLineColor, (Object)this.this$0.afterState.checkedLineColor);
                    this.this$0.viewState.radius = this.this$0.beforeState.radius + (this.this$0.afterState.radius - this.this$0.beforeState.radius) * floatValue;
                    if (this.this$0.animateState != 1) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                    }
                    this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkStateColor, (Object)this.this$0.afterState.checkStateColor);
                }
                this.this$0.postInvalidate();
            }
        };
        this.animatorListener = (Animator$AnimatorListener)new Animator$AnimatorListener() {
            final SwitchStyle this$0;
            
            public void onAnimationCancel(final Animator animator) {
            }
            
            public void onAnimationEnd(final Animator animator) {
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1) {
                    if (access$300 != 3) {
                        if (access$300 != 4) {
                            if (access$300 == 5) {
                                final SwitchStyle this$0 = this.this$0;
                                this$0.isChecked ^= true;
                                this.this$0.animateState = 0;
                                this.this$0.postInvalidate();
                                this.this$0.broadcastEvent();
                            }
                        }
                        else {
                            this.this$0.animateState = 0;
                            this.this$0.postInvalidate();
                            this.this$0.broadcastEvent();
                        }
                    }
                    else {
                        this.this$0.animateState = 0;
                        this.this$0.postInvalidate();
                    }
                }
                else {
                    this.this$0.animateState = 2;
                    this.this$0.viewState.checkedLineColor = 0;
                    this.this$0.viewState.radius = this.this$0.viewRadius;
                    this.this$0.postInvalidate();
                }
            }
            
            public void onAnimationRepeat(final Animator animator) {
            }
            
            public void onAnimationStart(final Animator animator) {
            }
        };
        this.init(context, set);
    }
    
    public SwitchStyle(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.ANIMATE_STATE_NONE = 0;
        this.ANIMATE_STATE_PENDING_DRAG = 1;
        this.ANIMATE_STATE_DRAGING = 2;
        this.ANIMATE_STATE_PENDING_RESET = 3;
        this.ANIMATE_STATE_PENDING_SETTLE = 4;
        this.ANIMATE_STATE_SWITCH = 5;
        this.buttonEdgeFrame = true;
        this.rect = new RectF();
        this.animateState = 0;
        this.argbEvaluator = new ArgbEvaluator();
        this.isTouchingDown = false;
        this.isUiInited = false;
        this.isEventBroadcast = false;
        this.postPendingDrag = (Runnable)new Runnable() {
            final SwitchStyle this$0;
            
            public void run() {
                if (!this.this$0.isInAnimating()) {
                    this.this$0.pendingDragState();
                }
            }
        };
        this.animatorUpdateListener = (ValueAnimator$AnimatorUpdateListener)new ValueAnimator$AnimatorUpdateListener() {
            final SwitchStyle this$0;
            
            public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                final float floatValue = (float)valueAnimator.getAnimatedValue();
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1 && access$300 != 3 && access$300 != 4) {
                    if (access$300 == 5) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                        final float n = (this.this$0.viewState.buttonX - this.this$0.buttonMinX) / (this.this$0.buttonMaxX - this.this$0.buttonMinX);
                        this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)this.this$0.uncheckColor, (Object)this.this$0.checkedColor);
                        this.this$0.viewState.radius = this.this$0.viewRadius * n;
                        this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)0, (Object)this.this$0.checkLineColor);
                    }
                }
                else {
                    this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkedLineColor, (Object)this.this$0.afterState.checkedLineColor);
                    this.this$0.viewState.radius = this.this$0.beforeState.radius + (this.this$0.afterState.radius - this.this$0.beforeState.radius) * floatValue;
                    if (this.this$0.animateState != 1) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                    }
                    this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkStateColor, (Object)this.this$0.afterState.checkStateColor);
                }
                this.this$0.postInvalidate();
            }
        };
        this.animatorListener = (Animator$AnimatorListener)new Animator$AnimatorListener() {
            final SwitchStyle this$0;
            
            public void onAnimationCancel(final Animator animator) {
            }
            
            public void onAnimationEnd(final Animator animator) {
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1) {
                    if (access$300 != 3) {
                        if (access$300 != 4) {
                            if (access$300 == 5) {
                                final SwitchStyle this$0 = this.this$0;
                                this$0.isChecked ^= true;
                                this.this$0.animateState = 0;
                                this.this$0.postInvalidate();
                                this.this$0.broadcastEvent();
                            }
                        }
                        else {
                            this.this$0.animateState = 0;
                            this.this$0.postInvalidate();
                            this.this$0.broadcastEvent();
                        }
                    }
                    else {
                        this.this$0.animateState = 0;
                        this.this$0.postInvalidate();
                    }
                }
                else {
                    this.this$0.animateState = 2;
                    this.this$0.viewState.checkedLineColor = 0;
                    this.this$0.viewState.radius = this.this$0.viewRadius;
                    this.this$0.postInvalidate();
                }
            }
            
            public void onAnimationRepeat(final Animator animator) {
            }
            
            public void onAnimationStart(final Animator animator) {
            }
        };
        this.init(context, set);
    }
    
    public SwitchStyle(final Context context, final AttributeSet set, final int n, final int n2) {
        super(context, set, n, n2);
        this.ANIMATE_STATE_NONE = 0;
        this.ANIMATE_STATE_PENDING_DRAG = 1;
        this.ANIMATE_STATE_DRAGING = 2;
        this.ANIMATE_STATE_PENDING_RESET = 3;
        this.ANIMATE_STATE_PENDING_SETTLE = 4;
        this.ANIMATE_STATE_SWITCH = 5;
        this.buttonEdgeFrame = true;
        this.rect = new RectF();
        this.animateState = 0;
        this.argbEvaluator = new ArgbEvaluator();
        this.isTouchingDown = false;
        this.isUiInited = false;
        this.isEventBroadcast = false;
        this.postPendingDrag = (Runnable)new Runnable() {
            final SwitchStyle this$0;
            
            public void run() {
                if (!this.this$0.isInAnimating()) {
                    this.this$0.pendingDragState();
                }
            }
        };
        this.animatorUpdateListener = (ValueAnimator$AnimatorUpdateListener)new ValueAnimator$AnimatorUpdateListener() {
            final SwitchStyle this$0;
            
            public void onAnimationUpdate(final ValueAnimator valueAnimator) {
                final float floatValue = (float)valueAnimator.getAnimatedValue();
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1 && access$300 != 3 && access$300 != 4) {
                    if (access$300 == 5) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                        final float n = (this.this$0.viewState.buttonX - this.this$0.buttonMinX) / (this.this$0.buttonMaxX - this.this$0.buttonMinX);
                        this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)this.this$0.uncheckColor, (Object)this.this$0.checkedColor);
                        this.this$0.viewState.radius = this.this$0.viewRadius * n;
                        this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(n, (Object)0, (Object)this.this$0.checkLineColor);
                    }
                }
                else {
                    this.this$0.viewState.checkedLineColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkedLineColor, (Object)this.this$0.afterState.checkedLineColor);
                    this.this$0.viewState.radius = this.this$0.beforeState.radius + (this.this$0.afterState.radius - this.this$0.beforeState.radius) * floatValue;
                    if (this.this$0.animateState != 1) {
                        this.this$0.viewState.buttonX = this.this$0.beforeState.buttonX + (this.this$0.afterState.buttonX - this.this$0.beforeState.buttonX) * floatValue;
                    }
                    this.this$0.viewState.checkStateColor = (int)this.this$0.argbEvaluator.evaluate(floatValue, (Object)this.this$0.beforeState.checkStateColor, (Object)this.this$0.afterState.checkStateColor);
                }
                this.this$0.postInvalidate();
            }
        };
        this.animatorListener = (Animator$AnimatorListener)new Animator$AnimatorListener() {
            final SwitchStyle this$0;
            
            public void onAnimationCancel(final Animator animator) {
            }
            
            public void onAnimationEnd(final Animator animator) {
                final int access$300 = this.this$0.animateState;
                if (access$300 != 1) {
                    if (access$300 != 3) {
                        if (access$300 != 4) {
                            if (access$300 == 5) {
                                final SwitchStyle this$0 = this.this$0;
                                this$0.isChecked ^= true;
                                this.this$0.animateState = 0;
                                this.this$0.postInvalidate();
                                this.this$0.broadcastEvent();
                            }
                        }
                        else {
                            this.this$0.animateState = 0;
                            this.this$0.postInvalidate();
                            this.this$0.broadcastEvent();
                        }
                    }
                    else {
                        this.this$0.animateState = 0;
                        this.this$0.postInvalidate();
                    }
                }
                else {
                    this.this$0.animateState = 2;
                    this.this$0.viewState.checkedLineColor = 0;
                    this.this$0.viewState.radius = this.this$0.viewRadius;
                    this.this$0.postInvalidate();
                }
            }
            
            public void onAnimationRepeat(final Animator animator) {
            }
            
            public void onAnimationStart(final Animator animator) {
            }
        };
        this.init(context, set);
    }
    
    private void broadcastEvent() {
        final OnCheckedChangeListener onCheckedChangeListener = this.onCheckedChangeListener;
        if (onCheckedChangeListener != null) {
            this.isEventBroadcast = true;
            onCheckedChangeListener.onCheckedChanged(this, this.isChecked());
        }
        this.isEventBroadcast = false;
    }
    
    private static float dp2px(final float n) {
        return TypedValue.applyDimension(1, n, Resources.getSystem().getDisplayMetrics());
    }
    
    private static int dp2pxInt(final float n) {
        return (int)dp2px(n);
    }
    
    private void drawArc(final Canvas canvas, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final Paint paint) {
        if (Build$VERSION.SDK_INT >= 21) {
            canvas.drawArc(n, n2, n3, n4, n5, n6, true, paint);
        }
        else {
            this.rect.set(n, n2, n3, n4);
            canvas.drawArc(this.rect, n5, n6, true, paint);
        }
    }
    
    private void drawButton(final Canvas canvas, final float n, final float n2) {
        canvas.drawCircle(n, n2, this.buttonRadius, this.buttonPaint);
        this.paint.setStyle(Paint$Style.STROKE);
        this.paint.setStrokeWidth(0.0f);
        this.paint.setColor(-2236963);
        if (this.buttonEdgeFrame) {
            canvas.drawCircle(n, n2, this.buttonRadius, this.paint);
        }
    }
    
    private void drawRoundRect(final Canvas canvas, final float n, final float n2, final float n3, final float n4, final float n5, final Paint paint) {
        if (Build$VERSION.SDK_INT >= 21) {
            canvas.drawRoundRect(n, n2, n3, n4, n5, n5, paint);
        }
        else {
            this.rect.set(n, n2, n3, n4);
            canvas.drawRoundRect(this.rect, n5, n5, paint);
        }
    }
    
    private void drawUncheckIndicator(final Canvas canvas) {
        this.drawUncheckIndicator(canvas, this.uncheckCircleColor, (float)this.uncheckCircleWidth, this.right - this.uncheckCircleOffsetX, this.centerY, this.uncheckCircleRadius, this.paint);
    }
    
    private void init(final Context context, final AttributeSet set) {
        this.shadowEffect = optBoolean(null, 0, true);
        this.uncheckCircleColor = optColor(null, 0, 11184810);
        this.uncheckCircleWidth = optPixelSize(null, 0, dp2pxInt(1.5f));
        this.uncheckCircleOffsetX = dp2px(10.0f);
        this.uncheckCircleRadius = optPixelSize(null, 0, dp2px(4.0f));
        this.checkedLineOffsetX = dp2px(0.0f);
        this.checkedLineOffsetY = dp2px(0.0f);
        this.shadowRadius = optPixelSize(null, 0, dp2pxInt(2.5f));
        this.shadowOffset = optPixelSize(null, 0, dp2pxInt(1.5f));
        this.shadowColor = optColor(null, 0, -16777216);
        this.uncheckColor = optColor(null, Color.parseColor("#ff000000"), -16777216);
        this.checkedColor = optColor(null, Menu.PrimaryColor, Menu.PrimaryColor);
        this.borderWidth = optPixelSize(null, 0, dp2pxInt(1.0f));
        this.checkLineColor = optColor(null, 0, 0);
        this.checkLineWidth = optPixelSize(null, 0, dp2pxInt(0.0f));
        this.checkLineLength = dp2px(6.0f);
        final int optColor = optColor(null, 0, -1);
        this.uncheckButtonColor = optColor(null, Color.parseColor("#ff000000"), optColor);
        this.checkedButtonColor = optColor(null, Menu.PrimaryColor, optColor);
        final int optInt = optInt(null, 0, 300);
        this.isChecked = optBoolean(null, 0, false);
        this.showIndicator = optBoolean(null, 0, true);
        this.background = optColor(null, 0, -1);
        this.enableEffect = optBoolean(null, 0, true);
        if (false) {
            throw new NullPointerException();
        }
        this.paint = new Paint(1);
        (this.buttonPaint = new Paint(1)).setColor(optColor);
        if (this.shadowEffect) {
            this.buttonPaint.setShadowLayer((float)this.shadowRadius, 0.0f, (float)this.shadowOffset, this.shadowColor);
        }
        this.viewState = new ViewState();
        this.beforeState = new ViewState();
        this.afterState = new ViewState();
        (this.valueAnimator = ValueAnimator.ofFloat(new float[] { 0.0f, 1.0f })).setDuration((long)optInt);
        this.valueAnimator.setRepeatCount(0);
        this.valueAnimator.addUpdateListener(this.animatorUpdateListener);
        this.valueAnimator.addListener(this.animatorListener);
        super.setClickable(true);
        this.setPadding(0, 0, 0, 0);
        if (Build$VERSION.SDK_INT >= 11) {
            this.setLayerType(1, (Paint)null);
        }
    }
    
    private boolean isDragState() {
        return this.animateState == 2;
    }
    
    private boolean isInAnimating() {
        return this.animateState != 0;
    }
    
    private boolean isPendingDragState() {
        final int animateState = this.animateState;
        boolean b = true;
        if (animateState != 1) {
            b = (animateState == 3 && b);
        }
        return b;
    }
    
    private static boolean optBoolean(final TypedArray typedArray, final int n, final boolean b) {
        if (typedArray == null) {
            return b;
        }
        return typedArray.getBoolean(n, b);
    }
    
    private static int optColor(final TypedArray typedArray, final int n, final int n2) {
        if (typedArray == null) {
            return n2;
        }
        return typedArray.getColor(n, n2);
    }
    
    private static int optInt(final TypedArray typedArray, final int n, final int n2) {
        if (typedArray == null) {
            return n2;
        }
        return typedArray.getInt(n, n2);
    }
    
    private static float optPixelSize(final TypedArray typedArray, final int n, final float n2) {
        if (typedArray == null) {
            return n2;
        }
        return typedArray.getDimension(n, n2);
    }
    
    private static int optPixelSize(final TypedArray typedArray, final int n, final int n2) {
        if (typedArray == null) {
            return n2;
        }
        return typedArray.getDimensionPixelOffset(n, n2);
    }
    
    private void pendingCancelDragState() {
        if (this.isDragState() || this.isPendingDragState()) {
            if (this.valueAnimator.isRunning()) {
                this.valueAnimator.cancel();
            }
            this.animateState = 3;
            this.beforeState.copy(this.viewState);
            if (this.isChecked()) {
                this.setCheckedViewState(this.afterState);
            }
            else {
                this.setUncheckViewState(this.afterState);
            }
            this.valueAnimator.start();
        }
    }
    
    private void pendingDragState() {
        if (this.isInAnimating()) {
            return;
        }
        if (!this.isTouchingDown) {
            return;
        }
        if (this.valueAnimator.isRunning()) {
            this.valueAnimator.cancel();
        }
        this.animateState = 1;
        this.beforeState.copy(this.viewState);
        this.afterState.copy(this.viewState);
        if (this.isChecked()) {
            this.afterState.checkStateColor = this.checkedColor;
            this.afterState.buttonX = this.buttonMaxX;
            this.afterState.checkedLineColor = this.checkedColor;
        }
        else {
            this.afterState.checkStateColor = this.uncheckColor;
            this.afterState.buttonX = this.buttonMinX;
            this.afterState.radius = this.viewRadius;
        }
        this.valueAnimator.start();
    }
    
    private void pendingSettleState() {
        if (this.valueAnimator.isRunning()) {
            this.valueAnimator.cancel();
        }
        this.animateState = 4;
        this.beforeState.copy(this.viewState);
        if (this.isChecked()) {
            this.setCheckedViewState(this.afterState);
        }
        else {
            this.setUncheckViewState(this.afterState);
        }
        this.valueAnimator.start();
    }
    
    private void setCheckedViewState(final ViewState viewState) {
        viewState.radius = this.viewRadius;
        viewState.checkStateColor = this.checkedColor;
        viewState.checkedLineColor = this.checkLineColor;
        viewState.buttonX = this.buttonMaxX;
        this.buttonPaint.setColor(this.checkedButtonColor);
    }
    
    private void setUncheckViewState(final ViewState viewState) {
        viewState.radius = 0.0f;
        viewState.checkStateColor = this.uncheckColor;
        viewState.checkedLineColor = 0;
        viewState.buttonX = this.buttonMinX;
        this.buttonPaint.setColor(this.uncheckButtonColor);
    }
    
    private void toggle(final boolean b, final boolean b2) {
        if (!this.isEnabled()) {
            return;
        }
        if (this.isEventBroadcast) {
            throw new RuntimeException("should NOT switch the state in method: [onCheckedChanged]!");
        }
        if (!this.isUiInited) {
            this.isChecked ^= true;
            if (b2) {
                this.broadcastEvent();
            }
            return;
        }
        if (this.valueAnimator.isRunning()) {
            this.valueAnimator.cancel();
        }
        if (this.enableEffect && b) {
            this.animateState = 5;
            this.beforeState.copy(this.viewState);
            if (this.isChecked()) {
                this.setUncheckViewState(this.afterState);
            }
            else {
                this.setCheckedViewState(this.afterState);
            }
            this.valueAnimator.start();
            return;
        }
        this.isChecked ^= true;
        if (this.isChecked()) {
            this.setCheckedViewState(this.viewState);
        }
        else {
            this.setUncheckViewState(this.viewState);
        }
        this.postInvalidate();
        if (b2) {
            this.broadcastEvent();
        }
    }
    
    protected void drawCheckedIndicator(final Canvas canvas) {
        final int checkedLineColor = this.viewState.checkedLineColor;
        final float n = (float)this.checkLineWidth;
        final float left = this.left;
        final float viewRadius = this.viewRadius;
        final float checkedLineOffsetX = this.checkedLineOffsetX;
        final float centerY = this.centerY;
        final float checkLineLength = this.checkLineLength;
        this.drawCheckedIndicator(canvas, checkedLineColor, n, left + viewRadius - checkedLineOffsetX, centerY - checkLineLength, left + viewRadius - this.checkedLineOffsetY, centerY + checkLineLength, this.paint);
    }
    
    protected void drawCheckedIndicator(final Canvas canvas, final int color, final float strokeWidth, final float n, final float n2, final float n3, final float n4, final Paint paint) {
        paint.setStyle(Paint$Style.STROKE);
        paint.setColor(color);
        paint.setStrokeWidth(strokeWidth);
        canvas.drawLine(n, n2, n3, n4, paint);
    }
    
    protected void drawUncheckIndicator(final Canvas canvas, final int color, final float n, final float n2, final float n3, final float n4, final Paint paint) {
        paint.setStyle(Paint$Style.STROKE);
        paint.setColor(color);
        paint.setStrokeWidth(0.0f);
        canvas.drawCircle(n2, n3, n4, paint);
    }
    
    public boolean isChecked() {
        return this.isChecked;
    }
    
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        this.paint.setStyle(Paint$Style.FILL);
        this.paint.setColor(-1);
        this.drawRoundRect(canvas, this.left, this.top, this.right, this.bottom, this.viewRadius, this.paint);
        this.paint.setStyle(Paint$Style.STROKE);
        this.paint.setColor(this.uncheckColor);
        this.drawRoundRect(canvas, this.left, this.top, this.right, this.bottom, this.viewRadius, this.paint);
        if (this.showIndicator) {
            this.drawUncheckIndicator(canvas);
        }
        final float n = this.viewState.radius * 0.5f;
        this.paint.setStyle(Paint$Style.STROKE);
        this.paint.setColor(this.viewState.checkStateColor);
        this.paint.setStrokeWidth(this.borderWidth + n * 2.0f);
        this.drawRoundRect(canvas, this.left + n, this.top + n, this.right - n, this.bottom - n, this.viewRadius, this.paint);
        this.paint.setStyle(Paint$Style.FILL);
        this.paint.setStrokeWidth(0.0f);
        final float left = this.left;
        final float top = this.top;
        final float viewRadius = this.viewRadius;
        this.drawArc(canvas, left, top, left + viewRadius * 2.0f, top + viewRadius * 2.0f, 90.0f, 180.0f, this.paint);
        canvas.drawRect(this.left + this.viewRadius, this.top, this.viewState.buttonX, this.top + this.viewRadius * 2.0f, this.paint);
        if (this.showIndicator) {
            this.drawCheckedIndicator(canvas);
        }
        this.drawButton(canvas, this.viewState.buttonX, this.centerY);
    }
    
    protected void onMeasure(int measureSpec, int measureSpec2) {
        final int mode = View$MeasureSpec.getMode(measureSpec);
        final int mode2 = View$MeasureSpec.getMode(measureSpec2);
        if (mode == 0 || mode == Integer.MIN_VALUE) {
            measureSpec = View$MeasureSpec.makeMeasureSpec(SwitchStyle.DEFAULT_WIDTH, 1073741824);
        }
        if (mode2 == 0 || mode2 == Integer.MIN_VALUE) {
            measureSpec2 = View$MeasureSpec.makeMeasureSpec(SwitchStyle.DEFAULT_HEIGHT, 1073741824);
        }
        super.onMeasure(measureSpec, measureSpec2);
    }
    
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        final float n5 = (float)Math.max(this.shadowRadius + this.shadowOffset, this.borderWidth);
        final float height = n2 - n5 - n5;
        this.height = height;
        this.width = n - n5 - n5;
        final float viewRadius = height * 0.5f;
        this.viewRadius = viewRadius;
        this.buttonRadius = viewRadius - this.borderWidth;
        this.left = n5;
        this.top = n5;
        final float right = n - n5;
        this.right = right;
        final float bottom = n2 - n5;
        this.bottom = bottom;
        this.centerX = (n5 + right) * 0.5f;
        this.centerY = (bottom + n5) * 0.5f;
        this.buttonMinX = n5 + viewRadius;
        this.buttonMaxX = right - viewRadius;
        if (this.isChecked()) {
            this.setCheckedViewState(this.viewState);
        }
        else {
            this.setUncheckViewState(this.viewState);
        }
        this.isUiInited = true;
        this.postInvalidate();
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        final boolean enabled = this.isEnabled();
        boolean isChecked = false;
        if (!enabled) {
            return false;
        }
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked == 3) {
                        this.isTouchingDown = false;
                        this.removeCallbacks(this.postPendingDrag);
                        if (this.isPendingDragState() || this.isDragState()) {
                            this.pendingCancelDragState();
                        }
                    }
                }
                else {
                    final float x = motionEvent.getX();
                    if (this.isPendingDragState()) {
                        final float max = Math.max(0.0f, Math.min(1.0f, x / this.getWidth()));
                        final ViewState viewState = this.viewState;
                        final float buttonMinX = this.buttonMinX;
                        viewState.buttonX = buttonMinX + (this.buttonMaxX - buttonMinX) * max;
                    }
                    else if (this.isDragState()) {
                        final float max2 = Math.max(0.0f, Math.min(1.0f, x / this.getWidth()));
                        final ViewState viewState2 = this.viewState;
                        final float buttonMinX2 = this.buttonMinX;
                        viewState2.buttonX = buttonMinX2 + (this.buttonMaxX - buttonMinX2) * max2;
                        this.viewState.checkStateColor = (int)this.argbEvaluator.evaluate(max2, (Object)this.uncheckColor, (Object)this.checkedColor);
                        this.postInvalidate();
                    }
                }
            }
            else {
                this.isTouchingDown = false;
                this.removeCallbacks(this.postPendingDrag);
                if (System.currentTimeMillis() - this.touchDownTime <= 300L) {
                    this.toggle();
                }
                else if (this.isDragState()) {
                    if (Math.max(0.0f, Math.min(1.0f, motionEvent.getX() / this.getWidth())) > 0.5f) {
                        isChecked = true;
                    }
                    if (isChecked == this.isChecked()) {
                        this.pendingCancelDragState();
                    }
                    else {
                        this.isChecked = isChecked;
                        this.pendingSettleState();
                    }
                }
                else if (this.isPendingDragState()) {
                    this.pendingCancelDragState();
                }
            }
        }
        else {
            this.isTouchingDown = true;
            this.touchDownTime = System.currentTimeMillis();
            this.removeCallbacks(this.postPendingDrag);
            this.postDelayed(this.postPendingDrag, 50L);
        }
        return true;
    }
    
    public void setButtonEdgeFrame(final boolean buttonEdgeFrame) {
        this.buttonEdgeFrame = buttonEdgeFrame;
    }
    
    public void setChecked(final boolean b) {
        if (b == this.isChecked()) {
            this.postInvalidate();
            return;
        }
        this.toggle(this.enableEffect, false);
    }
    
    public void setCheckedButtonColor(final int checkedButtonColor) {
        this.checkedButtonColor = checkedButtonColor;
    }
    
    public void setEnableEffect(final boolean enableEffect) {
        this.enableEffect = enableEffect;
    }
    
    public void setOnCheckedChangeListener(final OnCheckedChangeListener onCheckedChangeListener) {
        this.onCheckedChangeListener = onCheckedChangeListener;
    }
    
    public final void setOnClickListener(final View$OnClickListener view$OnClickListener) {
    }
    
    public final void setOnLongClickListener(final View$OnLongClickListener view$OnLongClickListener) {
    }
    
    public final void setPadding(final int n, final int n2, final int n3, final int n4) {
        super.setPadding(0, 0, 0, 0);
    }
    
    public void setShadowEffect(final boolean shadowEffect) {
        if (this.shadowEffect == shadowEffect) {
            return;
        }
        this.shadowEffect = shadowEffect;
        if (shadowEffect) {
            this.buttonPaint.setShadowLayer((float)this.shadowRadius, 0.0f, (float)this.shadowOffset, this.shadowColor);
        }
        else {
            this.buttonPaint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        }
    }
    
    public void setUncheckedButtonColor(final int uncheckButtonColor) {
        this.uncheckButtonColor = uncheckButtonColor;
    }
    
    public void toggle() {
        this.toggle(true);
    }
    
    public void toggle(final boolean b) {
        this.toggle(b, true);
    }
    
    public interface OnCheckedChangeListener
    {
        void onCheckedChanged(final SwitchStyle p0, final boolean p1);
    }
    
    private static class ViewState
    {
        float buttonX;
        int checkStateColor;
        int checkedLineColor;
        float radius;
        
        ViewState() {
        }
        
        private void copy(final ViewState viewState) {
            this.buttonX = viewState.buttonX;
            this.checkStateColor = viewState.checkStateColor;
            this.checkedLineColor = viewState.checkedLineColor;
            this.radius = viewState.radius;
        }
    }
}
