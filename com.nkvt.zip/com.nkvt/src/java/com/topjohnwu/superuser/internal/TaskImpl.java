package com.topjohnwu.superuser.internal;

import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.Future;
import java.io.InterruptedIOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Callable;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.List;
import com.topjohnwu.superuser.Shell;

class TaskImpl implements Task
{
    static final byte[] END_CMD;
    static final String END_UUID;
    static final int UUID_LEN = 36;
    private final ResultImpl res;
    private final List<ShellInputSource> sources;
    
    static {
        END_CMD = String.format("__RET=$?;echo %1$s;echo %1$s >&2;echo $__RET;unset __RET\n", new Object[] { END_UUID = UUID.randomUUID().toString() }).getBytes(Utils.UTF_8);
    }
    
    TaskImpl(final List<ShellInputSource> sources, final ResultImpl res) {
        this.sources = sources;
        this.res = res;
    }
    
    @Override
    public void run(final OutputStream ex, final InputStream inputStream, final InputStream inputStream2) throws IOException {
        final Future submit = Shell.EXECUTOR.submit((Callable)new StreamGobbler.OUT(inputStream, this.res.out));
        final Future submit2 = Shell.EXECUTOR.submit((Callable)new StreamGobbler.ERR(inputStream2, this.res.err));
        final Iterator iterator = this.sources.iterator();
        while (iterator.hasNext()) {
            ((ShellInputSource)iterator.next()).serve((OutputStream)ex);
        }
        ((OutputStream)ex).write(TaskImpl.END_CMD);
        ((OutputStream)ex).flush();
        try {
            this.res.code = (int)submit.get();
            submit2.get();
            return;
        }
        catch (final InterruptedException ex) {}
        catch (final ExecutionException ex2) {}
        throw (InterruptedIOException)new InterruptedIOException().initCause((Throwable)ex);
    }
}
