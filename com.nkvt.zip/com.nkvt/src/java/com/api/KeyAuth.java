package com.api;

import org.json.JSONObject;
import java.io.OutputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;

public class KeyAuth
{
    private final String appname;
    private boolean initialized;
    private final String ownerid;
    private String sessionid;
    private final String url;
    private UserData userData;
    private final String version;
    
    public KeyAuth(final String appname, final String ownerid, final String version, final String url) {
        this.appname = appname;
        this.ownerid = ownerid;
        this.version = version;
        this.url = url;
    }
    
    private String sendPostRequest(String string, final String... array) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.url);
            sb.append(string);
            final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(sb.toString()).openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            httpURLConnection.setDoOutput(true);
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("type=");
            sb2.append(string);
            for (int i = 0; i < array.length; i += 2) {
                sb2.append('&');
                sb2.append(array[i]);
                sb2.append('=');
                sb2.append(array[i + 1]);
            }
            final OutputStream outputStream = httpURLConnection.getOutputStream();
            outputStream.write(sb2.toString().getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();
            final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(httpURLConnection.getInputStream()));
            final StringBuilder sb3 = new StringBuilder();
            while (true) {
                final String line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                sb3.append(line);
            }
            bufferedReader.close();
            string = sb3.toString();
            return string;
        }
        catch (final Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void ban(final BanCallback banCallback) {
        if (!this.initialized) {
            System.out.println("Please initialize first");
            return;
        }
        new Thread((Runnable)new _$$Lambda$KeyAuth$e1l2clvtOP_ayd03aVUoJlK_V_8(this, banCallback)).start();
    }
    
    public UserData getUserData() {
        return this.userData;
    }
    
    public void init(final InitCallback initCallback) {
        new Thread((Runnable)new _$$Lambda$KeyAuth$k_TlLm1bF3VZLVVAeQKUNq6Rwns(this, initCallback)).start();
    }
    
    public void license(final String s, final LicenseCallback licenseCallback) {
        if (!this.initialized) {
            System.out.println("Please initialize first");
            return;
        }
        new Thread((Runnable)new _$$Lambda$KeyAuth$i676pfRaXgOjM6ss1fBQqs15eqA(this, s, licenseCallback)).start();
    }
    
    public void login(final String s, final String s2, final LoginCallback loginCallback) {
        if (!this.initialized) {
            System.out.println("Please initialize first");
            return;
        }
        new Thread((Runnable)new _$$Lambda$KeyAuth$md10HFLIVF5PesGYhMDSifSlOG8(this, s, s2, loginCallback)).start();
    }
    
    public void upgrade(final String s, final String s2, final UpgradeCallback upgradeCallback) {
        if (!this.initialized) {
            System.out.println("Please initialize first");
            return;
        }
        new Thread((Runnable)new _$$Lambda$KeyAuth$XvBNhpuY9WPrLbBoum7yHVkzTaI(this, s, s2, upgradeCallback)).start();
    }
    
    public void webhook(final String s, final String s2, final WebhookCallback webhookCallback) {
        if (!this.initialized) {
            System.out.println("Please initialize first");
            return;
        }
        new Thread((Runnable)new _$$Lambda$KeyAuth$BAbtE5Xwhh4t8v3QqkiIgilKtc4(this, s, s2, webhookCallback)).start();
    }
    
    public interface BanCallback
    {
        void onFailure(final String p0);
        
        void onSuccess();
    }
    
    public interface InitCallback
    {
        void onFailure(final String p0);
        
        void onSuccess();
    }
    
    public interface LicenseCallback
    {
        void onFailure(final String p0);
        
        void onSuccess(final UserData p0);
    }
    
    public interface LoginCallback
    {
        void onFailure(final String p0);
        
        void onSuccess(final UserData p0);
    }
    
    public interface UpgradeCallback
    {
        void onFailure(final String p0);
        
        void onSuccess();
    }
    
    public interface WebhookCallback
    {
        void onFailure(final String p0);
        
        void onSuccess();
    }
}
