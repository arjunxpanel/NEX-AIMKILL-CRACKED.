package com.topjohnwu.superuser.internal;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RejectedExecutionException;
import com.topjohnwu.superuser.Shell;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.FutureTask;
import java.util.ArrayDeque;
import java.util.concurrent.Callable;
import java.util.concurrent.AbstractExecutorService;

public class SerialExecutorService extends AbstractExecutorService implements Callable<Void>
{
    private boolean isShutdown;
    private ArrayDeque<Runnable> mTasks;
    private FutureTask<Void> scheduleTask;
    
    public SerialExecutorService() {
        this.isShutdown = false;
        this.mTasks = (ArrayDeque<Runnable>)new ArrayDeque();
        this.scheduleTask = null;
    }
    
    public boolean awaitTermination(final long n, final TimeUnit timeUnit) throws InterruptedException {
        synchronized (this) {
            final FutureTask<Void> scheduleTask = this.scheduleTask;
            if (scheduleTask == null) {
                return true;
            }
            try {
                scheduleTask.get(n, timeUnit);
            }
            catch (final ExecutionException ex) {}
            catch (final TimeoutException ex2) {
                return false;
            }
        }
    }
    
    public Void call() {
        while (true) {
            monitorenter(this);
            try {
                final Runnable runnable = (Runnable)this.mTasks.poll();
                if (runnable == null) {
                    this.scheduleTask = null;
                    monitorexit(this);
                    return null;
                }
                monitorexit(this);
                runnable.run();
            }
            finally {
                monitorexit(this);
                while (true) {}
            }
        }
    }
    
    public void execute(final Runnable runnable) {
        synchronized (this) {
            if (!this.isShutdown) {
                this.mTasks.offer((Object)runnable);
                if (this.scheduleTask == null) {
                    this.scheduleTask = (FutureTask<Void>)new FutureTask((Callable)this);
                    Shell.EXECUTOR.execute((Runnable)this.scheduleTask);
                }
                return;
            }
            final StringBuilder sb = new StringBuilder();
            sb.append("Task ");
            sb.append(runnable.toString());
            sb.append(" rejected from ");
            sb.append(this.toString());
            throw new RejectedExecutionException(sb.toString());
        }
    }
    
    public boolean isShutdown() {
        synchronized (this) {
            return this.isShutdown;
        }
    }
    
    public boolean isTerminated() {
        synchronized (this) {
            return this.isShutdown && this.scheduleTask == null;
        }
    }
    
    public void shutdown() {
        synchronized (this) {
            this.isShutdown = true;
            this.mTasks.clear();
        }
    }
    
    public List<Runnable> shutdownNow() {
        synchronized (this) {
            this.isShutdown = true;
            final FutureTask<Void> scheduleTask = this.scheduleTask;
            if (scheduleTask != null) {
                scheduleTask.cancel(true);
            }
            try {
                return (List<Runnable>)new ArrayList((Collection)this.mTasks);
            }
            finally {
                this.mTasks.clear();
            }
        }
    }
}
