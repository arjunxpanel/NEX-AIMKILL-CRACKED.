package com.topjohnwu.superuser;

import android.os.Looper;
import java.util.Iterator;
import android.text.TextUtils;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;

public final class ShellUtils
{
    private ShellUtils() {
    }
    
    public static void cleanInputStream(final InputStream inputStream) {
        try {
            while (inputStream.available() != 0) {
                inputStream.skip((long)inputStream.available());
            }
        }
        catch (final IOException ex) {}
    }
    
    public static String escapedString(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append('\"');
        for (int length = s.length(), i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if ("$`\"\\".indexOf((int)char1) >= 0) {
                sb.append('\\');
            }
            sb.append(char1);
        }
        sb.append('\"');
        return sb.toString();
    }
    
    public static String fastCmd(final Shell shell, final String... array) {
        final List<String> out = shell.newJob().add(array).to((List<String>)new ArrayList(), null).exec().getOut();
        String s;
        if (isValidOutput(out)) {
            s = (String)out.get(out.size() - 1);
        }
        else {
            s = "";
        }
        return s;
    }
    
    public static String fastCmd(final String... array) {
        return fastCmd(Shell.getShell(), array);
    }
    
    public static boolean fastCmdResult(final Shell shell, final String... array) {
        return shell.newJob().add(array).to(null).exec().isSuccess();
    }
    
    public static boolean fastCmdResult(final String... array) {
        return fastCmdResult(Shell.getShell(), array);
    }
    
    public static long gcd(long n, long n2) {
        if (n == 0L) {
            return n2;
        }
        if (n2 == 0L) {
            return n;
        }
        int n3 = 0;
        long n4 = n2;
        long n5;
        while (true) {
            n5 = n;
            if (((n | n4) & 0x1L) != 0x0L) {
                break;
            }
            n >>= 1;
            n4 >>= 1;
            ++n3;
        }
        while (true) {
            n2 = n5;
            n = n4;
            if ((n5 & 0x1L) != 0x0L) {
                break;
            }
            n5 >>= 1;
        }
        while (true) {
            if ((n & 0x1L) == 0x0L) {
                n >>= 1;
            }
            else {
                if (n2 <= n) {
                    final long n6 = n;
                    n = n2;
                    n2 = n6;
                }
                final long n7 = n2 - n;
                if (n7 == 0L) {
                    break;
                }
                n2 = n;
                n = n7;
            }
        }
        return n << n3;
    }
    
    public static boolean isValidOutput(final List<String> list) {
        if (list != null && list.size() != 0) {
            final Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                if (!TextUtils.isEmpty((CharSequence)iterator.next())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean onMainThread() {
        return Looper.myLooper() != null && Looper.myLooper() == Looper.getMainLooper();
    }
}
