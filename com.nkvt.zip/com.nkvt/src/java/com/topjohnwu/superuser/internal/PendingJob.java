package com.topjohnwu.superuser.internal;

import java.util.concurrent.Executor;
import com.topjohnwu.superuser.NoShellException;
import java.util.ArrayList;
import com.topjohnwu.superuser.Shell;
import java.util.List;

class PendingJob extends JobImpl
{
    private final boolean isSU;
    private boolean retry;
    
    PendingJob(final boolean isSU) {
        this.isSU = isSU;
        this.retry = true;
        this.to((List<String>)NOPList.getInstance());
    }
    
    @Override
    public Result exec() {
        while (true) {
            try {
                this.shell = MainShell.get();
                if (this.isSU && !this.shell.isRoot()) {
                    this.close();
                    return ResultImpl.INSTANCE;
                }
                if (this.out instanceof NOPList) {
                    this.out = (List<String>)new ArrayList();
                }
                Result result = super.exec();
                if (this.retry && (result = result) == ResultImpl.SHELL_ERR) {
                    this.retry = false;
                    result = this.exec();
                }
                return result;
            }
            catch (final NoShellException ex) {
                continue;
            }
            break;
        }
    }
    
    @Override
    public void submit(final Executor executor, final ResultCallback resultCallback) {
        MainShell.get(null, new PendingJob$$ExternalSyntheticLambda0(this, executor, resultCallback));
    }
}
