package com.nkvt;

import android.widget.Button;
import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.os.Build$VERSION;
import android.view.MotionEvent;
import android.view.View$OnTouchListener;
import android.view.View$OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton$OnCheckedChangeListener;
import android.widget.CheckBox;
import android.widget.SeekBar$OnSeekBarChangeListener;
import android.graphics.PorterDuff$Mode;
import android.widget.SeekBar;
import android.text.Html;
import android.view.View;
import android.widget.TextView;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup$LayoutParams;
import android.widget.LinearLayout$LayoutParams;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Canvas;
import android.widget.Toast;
import com.topjohnwu.superuser.Shell;
import java.io.File;
import android.view.WindowManager$LayoutParams;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.content.Context;
import android.widget.LinearLayout;

public class Menu
{
    public static int PrimaryColor;
    static LinearLayout container_features;
    private static Context context;
    private static Utils utils;
    private int buttonClick;
    DrawView drawView;
    private FrameLayout frameLayout;
    private int injectType;
    private String target;
    private WindowManager windowManager;
    WindowManager$LayoutParams windowManagerDrawViewParams;
    private WindowManager$LayoutParams windowManagerParams;
    
    static {
        Menu.PrimaryColor = -65536;
    }
    
    public Menu(final Context context, final int injectType) {
        this.target = "com.dts.freefiremax";
        this.buttonClick = 0;
        Menu.context = context;
        Menu.utils = new Utils(context);
        this.injectType = injectType;
        System.loadLibrary("hawdawdawdawda");
        this.onCreate();
    }
    
    public static native void ChangesID(final int p0, final int p1);
    
    public static native void Functions();
    
    public static native void Init();
    
    private boolean InjectX86(String string) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append(Menu.context.getApplicationInfo().nativeLibraryDir);
            sb.append(File.separator);
            sb.append("libinjectEmulator.so");
            final String string2 = sb.toString();
            final StringBuilder sb2 = new StringBuilder();
            sb2.append(Menu.context.getApplicationInfo().nativeLibraryDir);
            sb2.append(File.separator);
            sb2.append(string);
            final String string3 = sb2.toString();
            final StringBuilder sb3 = new StringBuilder();
            sb3.append("/data/local/tmp/");
            sb3.append(string);
            string = sb3.toString();
            final StringBuilder sb4 = new StringBuilder();
            sb4.append("rm -f ");
            sb4.append("/data/local/tmp/libinject");
            Shell.su(sb4.toString()).exec();
            final StringBuilder sb5 = new StringBuilder();
            sb5.append("rm -f ");
            sb5.append(string);
            Shell.su(sb5.toString()).exec();
            final StringBuilder sb6 = new StringBuilder();
            sb6.append("rm -f ");
            sb6.append("/data/local/tmp/libmeuovo.so");
            Shell.su(sb6.toString()).exec();
            final StringBuilder sb7 = new StringBuilder();
            sb7.append("cat ");
            sb7.append(string2);
            sb7.append(" > ");
            sb7.append("/data/local/tmp/libinject");
            Shell.su(sb7.toString()).exec();
            final StringBuilder sb8 = new StringBuilder();
            sb8.append("cat ");
            sb8.append(string3);
            sb8.append(" > ");
            sb8.append(string);
            Shell.su(sb8.toString()).exec();
            final StringBuilder sb9 = new StringBuilder();
            sb9.append("cat ");
            sb9.append(string3);
            sb9.append(" > ");
            sb9.append("/data/local/tmp/libmeuovo.so");
            Shell.su(sb9.toString()).exec();
            final StringBuilder sb10 = new StringBuilder();
            sb10.append("chmod 777 ");
            sb10.append("/data/local/tmp/libinject");
            Shell.su(sb10.toString()).exec();
            final StringBuilder sb11 = new StringBuilder();
            sb11.append("chmod 777 ");
            sb11.append(string);
            Shell.su(sb11.toString()).exec();
            final StringBuilder sb12 = new StringBuilder();
            sb12.append("chmod 777 ");
            sb12.append("/data/local/tmp/libmeuovo.so");
            Shell.su(sb12.toString()).exec();
            final StringBuilder sb13 = new StringBuilder();
            sb13.append("su -c \"/data/local/tmp/libinject -pkg com.dts.freefiremax -lib ");
            sb13.append(string);
            sb13.append(" -open -dl_memfd\"");
            Shell.su(sb13.toString()).exec();
            final StringBuilder sb14 = new StringBuilder();
            sb14.append("rm -f ");
            sb14.append("/data/local/tmp/libinject");
            Shell.su(sb14.toString()).exec();
            final StringBuilder sb15 = new StringBuilder();
            sb15.append("rm -f ");
            sb15.append(string);
            Shell.su(sb15.toString()).exec();
            final StringBuilder sb16 = new StringBuilder();
            sb16.append("rm -f ");
            sb16.append("/data/local/tmp/libmeuovo.so");
            Shell.su(sb16.toString()).exec();
            Functions();
            Toast.makeText(Menu.context, (CharSequence)"Injection Successful", 0).show();
            return true;
        }
        catch (final Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public static native void OnDrawLoad(final DrawView p0, final Canvas p1);
    
    public static void addCategory(final String text) {
        final GradientDrawable background = new GradientDrawable();
        background.setColor(Menu.PrimaryColor);
        background.setCornerRadius((float)Menu.utils.FixDP(4));
        final LinearLayout linearLayout = new LinearLayout(Menu.context);
        linearLayout.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, Menu.utils.FixDP(25)));
        linearLayout.setBackground((Drawable)background);
        linearLayout.setGravity(17);
        final TextView textView = new TextView(Menu.context);
        textView.setText((CharSequence)text);
        textView.setTextSize(11.0f);
        textView.setTextColor(-1);
        Menu.container_features.addView((View)linearLayout);
        linearLayout.addView((View)textView);
    }
    
    public static void addSeekBar(final String s, final int progress, final int max, final String s2, final int n) {
        final LinearLayout linearLayout = new LinearLayout(Menu.context);
        linearLayout.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2));
        linearLayout.setPadding(0, Menu.utils.FixDP(2), 0, Menu.utils.FixDP(2));
        linearLayout.setOrientation(1);
        final TextView textView = new TextView(Menu.context);
        final StringBuilder sb = new StringBuilder();
        sb.append(s.concat(": "));
        sb.append(progress);
        sb.append(s2);
        textView.setText((CharSequence)sb.toString());
        textView.setTextSize(11.0f);
        textView.setTextColor(-1);
        if (s2.equals((Object)"Color")) {
            if (progress == 0) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(s);
                sb2.append(": <font color='#ffffff'>White</font>");
                textView.setText((CharSequence)Html.fromHtml(sb2.toString()));
            }
            else if (progress == 1) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append(s);
                sb3.append(": <font color='#00FF00'>Green</font>");
                textView.setText((CharSequence)Html.fromHtml(sb3.toString()));
            }
            else if (progress == 2) {
                final StringBuilder sb4 = new StringBuilder();
                sb4.append(s);
                sb4.append(": <font color='#0000FF'>Blue</font>");
                textView.setText((CharSequence)Html.fromHtml(sb4.toString()));
            }
            else if (progress == 3) {
                final StringBuilder sb5 = new StringBuilder();
                sb5.append(s);
                sb5.append(": <font color='#FF0000'>Red</font>");
                textView.setText((CharSequence)Html.fromHtml(sb5.toString()));
            }
            else if (progress == 4) {
                final StringBuilder sb6 = new StringBuilder();
                sb6.append(s);
                sb6.append(": <font color='#000000'>Black</font>");
                textView.setText((CharSequence)Html.fromHtml(sb6.toString()));
            }
            else if (progress == 5) {
                final StringBuilder sb7 = new StringBuilder();
                sb7.append(s);
                sb7.append(": <font color='#FFFF00'>Yellow</font>");
                textView.setText((CharSequence)Html.fromHtml(sb7.toString()));
            }
            else if (progress == 6) {
                final StringBuilder sb8 = new StringBuilder();
                sb8.append(s);
                sb8.append(": <font color='#00FFFF'>Cyan</font>");
                textView.setText((CharSequence)Html.fromHtml(sb8.toString()));
            }
            else if (progress == 7) {
                final StringBuilder sb9 = new StringBuilder();
                sb9.append(s);
                sb9.append(": <font color='#FF00FF'>Magenta</font>");
                textView.setText((CharSequence)Html.fromHtml(sb9.toString()));
            }
            else if (progress == 8) {
                final StringBuilder sb10 = new StringBuilder();
                sb10.append(s);
                sb10.append(": <font color='#808080'>Gray</font>");
                textView.setText((CharSequence)Html.fromHtml(sb10.toString()));
            }
            else if (progress == 9) {
                final StringBuilder sb11 = new StringBuilder();
                sb11.append(s);
                sb11.append(": <font color='#A020F0'>Purple</font>");
                textView.setText((CharSequence)Html.fromHtml(sb11.toString()));
            }
        }
        else if (s2.equals((Object)"BoxType")) {
            if (progress == 0) {
                textView.setText((CharSequence)s.concat(": Stroke"));
            }
            else if (progress == 1) {
                textView.setText((CharSequence)s.concat(": Filled"));
            }
            else if (progress == 2) {
                textView.setText((CharSequence)s.concat(": Rounded"));
            }
        }
        else if (s2.equals((Object)"LineType")) {
            if (progress == 0) {
                textView.setText((CharSequence)s.concat(": Top"));
            }
            else if (progress == 1) {
                textView.setText((CharSequence)s.concat(": Center"));
            }
            else if (progress == 2) {
                textView.setText((CharSequence)s.concat(": Bottom"));
            }
        }
        final SeekBar seekBar = new SeekBar(Menu.context);
        seekBar.getThumb().setColorFilter(Menu.PrimaryColor, PorterDuff$Mode.SRC_IN);
        seekBar.getProgressDrawable().setColorFilter(Menu.PrimaryColor, PorterDuff$Mode.SRC_IN);
        seekBar.setProgress(progress);
        seekBar.setMax(max);
        if (s2.equals((Object)"Color")) {
            seekBar.setMax(9);
        }
        else if (s2.equals((Object)"BoxType")) {
            seekBar.setMax(2);
        }
        else if (s2.equals((Object)"LineType")) {
            seekBar.setMax(2);
        }
        seekBar.setOnSeekBarChangeListener((SeekBar$OnSeekBarChangeListener)new SeekBar$OnSeekBarChangeListener(s2, textView, s, n) {
            final int val$ID;
            final String val$name;
            final TextView val$textView;
            final String val$type;
            
            public void onProgressChanged(final SeekBar seekBar, final int n, final boolean b) {
                if (this.val$type.equals((Object)"Color")) {
                    if (n == 0) {
                        final TextView val$textView = this.val$textView;
                        final StringBuilder sb = new StringBuilder();
                        sb.append(this.val$name);
                        sb.append(": <font color='#ffffff'>White</font>");
                        val$textView.setText((CharSequence)Html.fromHtml(sb.toString()));
                    }
                    else if (n == 1) {
                        final TextView val$textView2 = this.val$textView;
                        final StringBuilder sb2 = new StringBuilder();
                        sb2.append(this.val$name);
                        sb2.append(": <font color='#00FF00'>Green</font>");
                        val$textView2.setText((CharSequence)Html.fromHtml(sb2.toString()));
                    }
                    else if (n == 2) {
                        final TextView val$textView3 = this.val$textView;
                        final StringBuilder sb3 = new StringBuilder();
                        sb3.append(this.val$name);
                        sb3.append(": <font color='#0000FF'>Blue</font>");
                        val$textView3.setText((CharSequence)Html.fromHtml(sb3.toString()));
                    }
                    else if (n == 3) {
                        final TextView val$textView4 = this.val$textView;
                        final StringBuilder sb4 = new StringBuilder();
                        sb4.append(this.val$name);
                        sb4.append(": <font color='#FF0000'>Red</font>");
                        val$textView4.setText((CharSequence)Html.fromHtml(sb4.toString()));
                    }
                    else if (n == 4) {
                        final TextView val$textView5 = this.val$textView;
                        final StringBuilder sb5 = new StringBuilder();
                        sb5.append(this.val$name);
                        sb5.append(": <font color='#000000'>Black</font>");
                        val$textView5.setText((CharSequence)Html.fromHtml(sb5.toString()));
                    }
                    else if (n == 5) {
                        final TextView val$textView6 = this.val$textView;
                        final StringBuilder sb6 = new StringBuilder();
                        sb6.append(this.val$name);
                        sb6.append(": <font color='#FFFF00'>Yellow</font>");
                        val$textView6.setText((CharSequence)Html.fromHtml(sb6.toString()));
                    }
                    else if (n == 6) {
                        final TextView val$textView7 = this.val$textView;
                        final StringBuilder sb7 = new StringBuilder();
                        sb7.append(this.val$name);
                        sb7.append(": <font color='#00FFFF'>Cyan</font>");
                        val$textView7.setText((CharSequence)Html.fromHtml(sb7.toString()));
                    }
                    else if (n == 7) {
                        final TextView val$textView8 = this.val$textView;
                        final StringBuilder sb8 = new StringBuilder();
                        sb8.append(this.val$name);
                        sb8.append(": <font color='#FF00FF'>Magenta</font>");
                        val$textView8.setText((CharSequence)Html.fromHtml(sb8.toString()));
                    }
                    else if (n == 8) {
                        final TextView val$textView9 = this.val$textView;
                        final StringBuilder sb9 = new StringBuilder();
                        sb9.append(this.val$name);
                        sb9.append(": <font color='#808080'>Gray</font>");
                        val$textView9.setText((CharSequence)Html.fromHtml(sb9.toString()));
                    }
                    else if (n == 9) {
                        final TextView val$textView10 = this.val$textView;
                        final StringBuilder sb10 = new StringBuilder();
                        sb10.append(this.val$name);
                        sb10.append(": <font color='#A020F0'>Purple</font>");
                        val$textView10.setText((CharSequence)Html.fromHtml(sb10.toString()));
                    }
                }
                else if (this.val$type.equals((Object)"BoxType")) {
                    if (n == 0) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Stroke"));
                    }
                    else if (n == 1) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Filled"));
                    }
                    else if (n == 2) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Corner"));
                    }
                }
                else if (this.val$type.equals((Object)"LineType")) {
                    if (n == 0) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Top"));
                    }
                    else if (n == 1) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Center"));
                    }
                    else if (n == 2) {
                        this.val$textView.setText((CharSequence)this.val$name.concat(": Bottom"));
                    }
                }
                else {
                    final TextView val$textView11 = this.val$textView;
                    final StringBuilder sb11 = new StringBuilder();
                    sb11.append(this.val$name.concat(": "));
                    sb11.append(n);
                    sb11.append(this.val$type);
                    val$textView11.setText((CharSequence)sb11.toString());
                }
                Menu.ChangesID(this.val$ID, n);
            }
            
            public void onStartTrackingTouch(final SeekBar seekBar) {
            }
            
            public void onStopTrackingTouch(final SeekBar seekBar) {
            }
        });
        Menu.container_features.addView((View)linearLayout);
        linearLayout.addView((View)textView);
        linearLayout.addView((View)seekBar);
    }
    
    public static void addSwitch(final String s, final int n) {
        final LinearLayout linearLayout = new LinearLayout(Menu.context);
        linearLayout.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2));
        linearLayout.setPadding(Menu.utils.FixDP(5), Menu.utils.FixDP(2), Menu.utils.FixDP(5), Menu.utils.FixDP(2));
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        final TextView textView = new TextView(Menu.context);
        textView.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2, 1.0f));
        textView.setGravity(16);
        textView.setText((CharSequence)s);
        textView.setTextColor(-7829368);
        textView.setTextSize(12.0f);
        final CheckBox checkBox = new CheckBox(Menu.context);
        checkBox.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-2, -2));
        checkBox.getButtonDrawable().setTint(-65536);
        checkBox.setContentDescription((CharSequence)s);
        checkBox.setOnCheckedChangeListener((CompoundButton$OnCheckedChangeListener)new CompoundButton$OnCheckedChangeListener(n, textView) {
            final int val$ID;
            final TextView val$textView;
            
            public void onCheckedChanged(final CompoundButton compoundButton, final boolean b) {
                Menu.ChangesID(this.val$ID, 0);
                final TextView val$textView = this.val$textView;
                int textColor;
                if (b) {
                    textColor = -1;
                }
                else {
                    textColor = -7829368;
                }
                val$textView.setTextColor(textColor);
            }
        });
        linearLayout.setOnClickListener((View$OnClickListener)new View$OnClickListener(checkBox) {
            final CheckBox val$checkBox;
            
            public void onClick(final View view) {
                final CheckBox val$checkBox = this.val$checkBox;
                val$checkBox.setChecked(val$checkBox.isChecked() ^ true);
            }
        });
        linearLayout.addView((View)textView);
        linearLayout.addView((View)checkBox);
        Menu.container_features.addView((View)linearLayout);
    }
    
    private native String imageBase64();
    
    private View$OnTouchListener onTouchListener() {
        return (View$OnTouchListener)new View$OnTouchListener(this) {
            final Menu this$0;
            private int x;
            private int y;
            
            public boolean onTouch(final View view, final MotionEvent motionEvent) {
                final int action = motionEvent.getAction();
                if (action != 0) {
                    if (action != 1) {
                        if (action == 2) {
                            final int x = (int)motionEvent.getRawX();
                            final int y = (int)motionEvent.getRawY();
                            final int x2 = this.x;
                            final int y2 = this.y;
                            this.x = x;
                            this.y = y;
                            this.this$0.windowManagerParams.x += x - x2;
                            this.this$0.windowManagerParams.y += y - y2;
                            this.this$0.windowManager.updateViewLayout((View)this.this$0.frameLayout, (ViewGroup$LayoutParams)this.this$0.windowManagerParams);
                        }
                    }
                    else {
                        this.this$0.frameLayout.setAlpha(0.9f);
                    }
                }
                else {
                    this.x = (int)motionEvent.getRawX();
                    this.y = (int)motionEvent.getRawY();
                    this.this$0.frameLayout.setAlpha(0.8f);
                }
                return false;
            }
        };
    }
    
    public void DrawCanvas() {
        int n;
        if (Build$VERSION.SDK_INT >= 26) {
            n = 2038;
        }
        else {
            n = 2002;
        }
        this.drawView = new DrawView(Menu.context);
        final WindowManager$LayoutParams windowManagerDrawViewParams = new WindowManager$LayoutParams(-1, -1, n, 1080, -2);
        this.windowManagerDrawViewParams = windowManagerDrawViewParams;
        windowManagerDrawViewParams.gravity = 17;
        this.windowManager.addView((View)this.drawView, (ViewGroup$LayoutParams)this.windowManagerDrawViewParams);
    }
    
    public void onCreate() {
        this.onCreateSystemWindow();
        this.onCreateTemplate();
    }
    
    public void onCreateSystemWindow() {
        int n;
        if (Build$VERSION.SDK_INT >= 26) {
            n = 2038;
        }
        else {
            n = 2002;
        }
        (this.frameLayout = new FrameLayout(Menu.context)).setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-2, -2));
        this.frameLayout.setOnTouchListener(this.onTouchListener());
        this.frameLayout.setAlpha(0.8f);
        final WindowManager$LayoutParams windowManagerParams = new WindowManager$LayoutParams(-2, -2, n, 42074376, -2);
        this.windowManagerParams = windowManagerParams;
        windowManagerParams.gravity = 51;
        this.windowManagerParams.x = 15;
        this.windowManagerParams.y = 15;
        this.windowManager = (WindowManager)Menu.context.getSystemService("window");
        this.DrawCanvas();
        this.windowManager.addView((View)this.frameLayout, (ViewGroup$LayoutParams)this.windowManagerParams);
    }
    
    public void onCreateTemplate() {
        final GradientDrawable background = new GradientDrawable();
        background.setColor(-15658735);
        background.setCornerRadius((float)Menu.utils.FixDP(8));
        final LinearLayout linearLayout = new LinearLayout(Menu.context);
        linearLayout.setOrientation(1);
        final LinearLayout linearLayout2 = new LinearLayout(Menu.context);
        linearLayout2.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(Menu.utils.FixDP(210), -2));
        linearLayout2.setBackgroundColor(-15658735);
        linearLayout2.setVisibility(8);
        linearLayout2.setOrientation(1);
        linearLayout2.setBackground((Drawable)background);
        final ImageBase64 imageBase64 = new ImageBase64(Menu.context);
        imageBase64.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(Menu.utils.FixDP(50), Menu.utils.FixDP(50)));
        imageBase64.setImageBase64(this.imageBase64());
        imageBase64.setOnTouchListener(this.onTouchListener());
        imageBase64.setOnClickListener((View$OnClickListener)new View$OnClickListener(this, imageBase64, linearLayout2) {
            final Menu this$0;
            final LinearLayout val$container_menu;
            final ImageBase64 val$icon_cheat;
            
            public void onClick(final View view) {
                this.val$icon_cheat.setVisibility(8);
                this.val$container_menu.setVisibility(0);
            }
        });
        final LinearLayout linearLayout3 = new LinearLayout(Menu.context);
        linearLayout3.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2));
        linearLayout3.setPadding(Menu.utils.FixDP(8), Menu.utils.FixDP(8), Menu.utils.FixDP(8), Menu.utils.FixDP(8));
        linearLayout3.setGravity(17);
        linearLayout3.setOrientation(0);
        final ImageBase64 imageBase65 = new ImageBase64(Menu.context);
        imageBase65.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(Menu.utils.FixDP(45), Menu.utils.FixDP(45)));
        imageBase65.setImageBase64(this.imageBase64());
        final LinearLayout linearLayout4 = new LinearLayout(Menu.context);
        linearLayout4.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, Menu.utils.FixDP(180)));
        linearLayout4.setGravity(17);
        final ScrollView scrollView = new ScrollView(Menu.context);
        scrollView.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -1));
        (Menu.container_features = new LinearLayout(Menu.context)).setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -1));
        Menu.container_features.setPadding(Menu.utils.FixDP(8), 0, Menu.utils.FixDP(8), 0);
        Menu.container_features.setOrientation(1);
        final ProgressBar progressBar = new ProgressBar(Menu.context);
        progressBar.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(Menu.utils.FixDP(40), Menu.utils.FixDP(40)));
        progressBar.getIndeterminateDrawable().setColorFilter(Menu.PrimaryColor, PorterDuff$Mode.SRC_IN);
        final LinearLayout linearLayout5 = new LinearLayout(Menu.context);
        linearLayout5.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2));
        linearLayout5.setPadding(Menu.utils.FixDP(3), Menu.utils.FixDP(8), Menu.utils.FixDP(3), Menu.utils.FixDP(3));
        linearLayout5.setOrientation(1);
        linearLayout5.setGravity(21);
        final GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Menu.PrimaryColor);
        gradientDrawable.setCornerRadius((float)Menu.utils.FixDP(8));
        new RippleDrawable(ColorStateList.valueOf(-15658735), (Drawable)gradientDrawable, (Drawable)null);
        linearLayout4.addView((View)scrollView);
        final GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(Menu.PrimaryColor);
        gradientDrawable2.setCornerRadius((float)Menu.utils.FixDP(8));
        final RippleDrawable background2 = new RippleDrawable(ColorStateList.valueOf(-15658735), (Drawable)gradientDrawable2, (Drawable)null);
        final Button button = new Button(Menu.context);
        button.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, Menu.utils.FixDP(33)));
        button.setPadding(0, 0, 0, 0);
        button.setText((CharSequence)"INJECT CHEAT");
        button.setTextSize(10.0f);
        button.setTextColor(-1);
        button.setBackground((Drawable)background2);
        button.setOnClickListener((View$OnClickListener)new View$OnClickListener(this, button, imageBase64, linearLayout2) {
            final Menu this$0;
            final LinearLayout val$container_menu;
            final ImageBase64 val$icon_cheat;
            final Button val$inject_close;
            
            public void onClick(final View view) {
                if (this.this$0.buttonClick == 0) {
                    if (this.this$0.injectType != 0) {
                        if (this.this$0.injectType == 1 && this.this$0.InjectX86("libqqqqaaqwdqwd.so")) {
                            Menu.Init();
                            this.val$inject_close.setText((CharSequence)"MINIMIZE");
                            this.this$0.buttonClick++;
                        }
                    }
                }
                else if (this.this$0.buttonClick == 1) {
                    this.val$icon_cheat.setVisibility(0);
                    this.val$container_menu.setVisibility(8);
                }
            }
        });
        this.frameLayout.addView((View)linearLayout);
        linearLayout.addView((View)imageBase64);
        linearLayout.addView((View)linearLayout2);
        linearLayout2.addView((View)linearLayout3);
        linearLayout3.addView((View)imageBase65);
        linearLayout2.addView((View)linearLayout4);
        scrollView.addView((View)Menu.container_features);
        new View(Menu.context).setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, Menu.utils.FixDP(5)));
        linearLayout2.addView((View)linearLayout5);
        linearLayout5.addView((View)button);
    }
}
