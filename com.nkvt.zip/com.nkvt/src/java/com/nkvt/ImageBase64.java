package com.nkvt;

import android.graphics.BitmapFactory;
import android.util.Base64;
import android.content.Context;
import android.widget.ImageView;

public class ImageBase64 extends ImageView
{
    public ImageBase64(final Context context) {
        super(context);
    }
    
    public void setImageBase64(final String s) {
        final byte[] decode = Base64.decode(s, 0);
        this.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
    }
}
