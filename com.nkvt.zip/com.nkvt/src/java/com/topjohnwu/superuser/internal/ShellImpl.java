package com.topjohnwu.superuser.internal;

import java.io.BufferedOutputStream;
import java.io.FilterOutputStream;
import java.io.FilterInputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import com.topjohnwu.superuser.ShellUtils;
import java.util.concurrent.Future;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Callable;
import android.text.TextUtils;
import java.util.concurrent.ExecutorService;
import com.topjohnwu.superuser.Shell;

class ShellImpl extends Shell
{
    private static final String TAG = "SHELLIMPL";
    private final NoCloseInputStream STDERR;
    private final NoCloseOutputStream STDIN;
    private final NoCloseInputStream STDOUT;
    final ExecutorService executor;
    private final Process process;
    final boolean redirect;
    private int status;
    
    ShellImpl(final long n, final boolean redirect, final String... array) throws IOException {
        this.status = -1;
        this.redirect = redirect;
        final StringBuilder sb = new StringBuilder();
        sb.append("exec ");
        sb.append(TextUtils.join((CharSequence)" ", (Object[])array));
        Utils.log("SHELLIMPL", sb.toString());
        final Process exec = Runtime.getRuntime().exec(array);
        this.process = exec;
        this.STDIN = new NoCloseOutputStream(exec.getOutputStream());
        this.STDOUT = new NoCloseInputStream(exec.getInputStream());
        this.STDERR = new NoCloseInputStream(exec.getErrorStream());
        final SerialExecutorService executor = new SerialExecutorService();
        this.executor = (ExecutorService)executor;
        if (array.length >= 2 && TextUtils.equals((CharSequence)array[1], (CharSequence)"--mount-master")) {
            this.status = 2;
        }
        final Future submit = ((ExecutorService)executor).submit((Callable)new ShellImpl$$ExternalSyntheticLambda0(this));
        try {
            try {
                submit.get(n, TimeUnit.SECONDS);
                return;
                try {
                    final Throwable t;
                    throw new IOException("Shell timeout", t);
                }
                catch (final IOException ex) {}
            }
            catch (final IOException ex2) {}
        }
        catch (final InterruptedException ex3) {}
        catch (final TimeoutException ex4) {}
        catch (final ExecutionException ex5) {
            final ExecutionException ex6;
            final Throwable cause = ex6.getCause();
            if (cause instanceof IOException) {
                throw (IOException)cause;
            }
            throw new IOException("Unknown ExecutionException", cause);
        }
        this.executor.shutdownNow();
        this.release();
        throw;
    }
    
    private void release() {
        this.status = -1;
        try {
            this.STDIN.close0();
        }
        catch (final IOException ex) {}
        try {
            this.STDERR.close0();
        }
        catch (final IOException ex2) {}
        try {
            this.STDOUT.close0();
        }
        catch (final IOException ex3) {}
        this.process.destroy();
    }
    
    private Void shellCheck() throws IOException {
        ShellUtils.cleanInputStream((InputStream)this.STDOUT);
        ShellUtils.cleanInputStream((InputStream)this.STDERR);
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader((InputStream)this.STDOUT));
        try {
            this.STDIN.write("echo SHELL_TEST\n".getBytes(Utils.UTF_8));
            this.STDIN.flush();
            final String line = bufferedReader.readLine();
            if (!TextUtils.isEmpty((CharSequence)line) && line.contains((CharSequence)"SHELL_TEST")) {
                final int n = 0;
                this.STDIN.write("id\n".getBytes(Utils.UTF_8));
                this.STDIN.flush();
                final String line2 = bufferedReader.readLine();
                int n2 = n;
                if (!TextUtils.isEmpty((CharSequence)line2)) {
                    n2 = n;
                    if (line2.contains((CharSequence)"uid=0")) {
                        n2 = 1;
                    }
                }
                int status;
                if ((status = n2) == 1) {
                    status = n2;
                    if (this.status == 2) {
                        status = 2;
                    }
                }
                this.status = status;
                bufferedReader.close();
                return null;
            }
            throw new IOException("Created process is not a shell");
        }
        finally {
            try {
                bufferedReader.close();
            }
            finally {
                final Throwable t;
                final Throwable t2;
                t.addSuppressed(t2);
            }
        }
    }
    
    public void close() {
        if (this.status < 0) {
            return;
        }
        this.executor.shutdownNow();
        this.release();
    }
    
    @Override
    public void execTask(final Task task) throws IOException {
        synchronized (this) {
            if (this.status >= 0) {
                ShellUtils.cleanInputStream((InputStream)this.STDOUT);
                ShellUtils.cleanInputStream((InputStream)this.STDERR);
                try {
                    this.STDIN.write(10);
                    this.STDIN.flush();
                    task.run((OutputStream)this.STDIN, (InputStream)this.STDOUT, (InputStream)this.STDERR);
                    return;
                }
                catch (final IOException ex) {
                    this.release();
                    throw new ShellTerminatedException();
                }
            }
            throw new ShellTerminatedException();
        }
    }
    
    @Override
    public int getStatus() {
        return this.status;
    }
    
    @Override
    public boolean isAlive() {
        if (this.status < 0) {
            return false;
        }
        try {
            this.process.exitValue();
            return false;
        }
        catch (final IllegalThreadStateException ex) {
            return true;
        }
    }
    
    @Override
    public Job newJob() {
        return new JobImpl(this);
    }
    
    @Override
    public boolean waitAndClose(final long n, final TimeUnit timeUnit) throws InterruptedException {
        if (this.status < 0) {
            return true;
        }
        this.executor.shutdown();
        if (this.executor.awaitTermination(n, timeUnit)) {
            this.release();
            return true;
        }
        this.status = -1;
        return false;
    }
    
    private static class NoCloseInputStream extends FilterInputStream
    {
        NoCloseInputStream(final InputStream inputStream) {
            super(inputStream);
        }
        
        public void close() {
        }
        
        void close0() throws IOException {
            this.in.close();
        }
    }
    
    private static class NoCloseOutputStream extends FilterOutputStream
    {
        NoCloseOutputStream(OutputStream outputStream) {
            if (!(outputStream instanceof BufferedOutputStream)) {
                outputStream = (OutputStream)new BufferedOutputStream(outputStream);
            }
            super(outputStream);
        }
        
        public void close() throws IOException {
            this.out.flush();
        }
        
        void close0() throws IOException {
            super.close();
        }
        
        public void write(final byte[] array, final int n, final int n2) throws IOException {
            this.out.write(array, n, n2);
        }
    }
}
