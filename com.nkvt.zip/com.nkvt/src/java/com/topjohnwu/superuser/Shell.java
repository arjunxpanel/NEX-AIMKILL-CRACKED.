package com.topjohnwu.superuser;

import java.io.OutputStream;
import java.util.List;
import android.content.Context;
import com.topjohnwu.superuser.internal.BuilderImpl;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executor;
import com.topjohnwu.superuser.internal.UiThreadHandler;
import com.topjohnwu.superuser.internal.MainShell;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.io.Closeable;

public abstract class Shell implements Closeable
{
    public static ExecutorService EXECUTOR;
    public static final int FLAG_MOUNT_MASTER = 2;
    public static final int FLAG_NON_ROOT_SHELL = 1;
    public static final int FLAG_REDIRECT_STDERR = 8;
    public static final int NON_ROOT_SHELL = 0;
    public static final int ROOT_MOUNT_MASTER = 2;
    public static final int ROOT_SHELL = 1;
    public static final int UNKNOWN = -1;
    public static boolean enableVerboseLogging;
    
    static {
        Shell.EXECUTOR = Executors.newCachedThreadPool();
        Shell.enableVerboseLogging = false;
    }
    
    public static Shell getCachedShell() {
        return MainShell.getCached();
    }
    
    public static Shell getShell() {
        return MainShell.get();
    }
    
    public static void getShell(final GetShellCallback getShellCallback) {
        MainShell.get(UiThreadHandler.executor, getShellCallback);
    }
    
    public static void getShell(final Executor executor, final GetShellCallback getShellCallback) {
        MainShell.get(executor, getShellCallback);
    }
    
    public static boolean rootAccess() {
        try {
            return getShell().isRoot();
        }
        catch (final NoShellException ex) {
            return false;
        }
    }
    
    public static void setDefaultBuilder(final Builder builder) {
        MainShell.setBuilder(builder);
    }
    
    public static Job sh(final InputStream inputStream) {
        return MainShell.newJob(false, inputStream);
    }
    
    public static Job sh(final String... array) {
        return MainShell.newJob(false, array);
    }
    
    public static Job su(final InputStream inputStream) {
        return MainShell.newJob(true, inputStream);
    }
    
    public static Job su(final String... array) {
        return MainShell.newJob(true, array);
    }
    
    public abstract void execTask(final Task p0) throws IOException;
    
    public abstract int getStatus();
    
    public abstract boolean isAlive();
    
    public boolean isRoot() {
        final int status = this.getStatus();
        boolean b = true;
        if (status < 1) {
            b = false;
        }
        return b;
    }
    
    public abstract Job newJob();
    
    public void waitAndClose() throws IOException {
        while (true) {
            try {
                while (!this.waitAndClose(Long.MAX_VALUE, TimeUnit.NANOSECONDS)) {}
            }
            catch (final InterruptedException ex) {
                continue;
            }
            break;
        }
    }
    
    public abstract boolean waitAndClose(final long p0, final TimeUnit p1) throws IOException, InterruptedException;
    
    public abstract static class Builder
    {
        protected int flags;
        protected Class<? extends Initializer>[] initClasses;
        protected long timeout;
        
        public Builder() {
            this.flags = 0;
            this.timeout = 20L;
            this.initClasses = null;
        }
        
        public static Builder create() {
            return (Builder)new BuilderImpl();
        }
        
        public abstract Shell build();
        
        public abstract Shell build(final String... p0);
        
        public final Builder setFlags(final int flags) {
            this.flags = flags;
            return this;
        }
        
        @SafeVarargs
        public final Builder setInitializers(final Class<? extends Initializer>... initClasses) {
            this.initClasses = initClasses;
            return this;
        }
        
        public final Builder setTimeout(final long timeout) {
            this.timeout = timeout;
            return this;
        }
    }
    
    public interface GetShellCallback
    {
        void onShell(final Shell p0);
    }
    
    public static class Initializer
    {
        public boolean onInit(final Context context, final Shell shell) {
            return true;
        }
    }
    
    public abstract static class Job
    {
        public abstract Job add(final InputStream p0);
        
        public abstract Job add(final String... p0);
        
        public abstract Result exec();
        
        public void submit() {
            this.submit(null);
        }
        
        public void submit(final ResultCallback resultCallback) {
            this.submit(UiThreadHandler.executor, resultCallback);
        }
        
        public abstract void submit(final Executor p0, final ResultCallback p1);
        
        public abstract Job to(final List<String> p0);
        
        public abstract Job to(final List<String> p0, final List<String> p1);
    }
    
    public abstract static class Result
    {
        public static final int JOB_NOT_EXECUTED = -1;
        
        public abstract int getCode();
        
        public abstract List<String> getErr();
        
        public abstract List<String> getOut();
        
        public boolean isSuccess() {
            return this.getCode() == 0;
        }
    }
    
    public interface ResultCallback
    {
        void onResult(final Result p0);
    }
    
    public interface Task
    {
        void run(final OutputStream p0, final InputStream p1, final InputStream p2) throws IOException;
    }
}
