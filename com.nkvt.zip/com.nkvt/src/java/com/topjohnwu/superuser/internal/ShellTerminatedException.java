package com.topjohnwu.superuser.internal;

import java.io.IOException;

class ShellTerminatedException extends IOException
{
    ShellTerminatedException() {
        super("Shell terminated unexpectedly");
    }
}
