package com.topjohnwu.superuser.internal;

import java.lang.reflect.Constructor;
import android.content.Context;
import java.io.IOException;
import com.topjohnwu.superuser.NoShellException;
import com.topjohnwu.superuser.Shell;

public class BuilderImpl extends Builder
{
    public ShellImpl build() {
        final boolean hasFlags = this.hasFlags(1);
        final ShellImpl shellImpl = null;
        ShellImpl build = null;
        Label_0063: {
            Label_0060: {
                if (!hasFlags && this.hasFlags(2)) {
                    try {
                        build = this.build("su", "--mount-master");
                        try {
                            if (build.getStatus() != 2) {
                                break Label_0060;
                            }
                            break Label_0063;
                        }
                        catch (final NoShellException ex) {}
                    }
                    catch (final NoShellException ex2) {}
                }
            }
            build = null;
        }
        ShellImpl build2;
        if ((build2 = build) == null) {
            build2 = build;
            if (!this.hasFlags(1)) {
                build2 = build;
                try {
                    final ShellImpl shellImpl2 = build2 = this.build("su");
                    if (shellImpl2.getStatus() != 1) {
                        build2 = shellImpl;
                    }
                    else {
                        build2 = shellImpl2;
                    }
                }
                catch (final NoShellException ex3) {}
            }
        }
        ShellImpl build3;
        if ((build3 = build2) == null) {
            build3 = this.build("sh");
        }
        return build3;
    }
    
    public ShellImpl build(String... array) {
        try {
            array = (String[])(Object)new ShellImpl(this.timeout, this.hasFlags(8), array);
            MainShell.set((ShellImpl)(Object)array);
            if (this.initClasses != null) {
                final Context context = Utils.getContext();
                for (final Class<? extends Initializer> clazz : this.initClasses) {
                    try {
                        final java.lang.reflect.Constructor<? extends Initializer> declaredConstructor = clazz.getDeclaredConstructor((Class<?>[])new Class[0]);
                        declaredConstructor.setAccessible(true);
                        if (!((Initializer)declaredConstructor.newInstance(new Object[0])).onInit(context, (Shell)(Object)array)) {
                            MainShell.set(null);
                            throw new NoShellException("Unable to init shell");
                        }
                    }
                    catch (final Exception ex) {
                        Utils.err((Throwable)ex);
                    }
                }
            }
            return (ShellImpl)(Object)array;
        }
        catch (final IOException ex2) {
            Utils.ex((Throwable)ex2);
            throw new NoShellException("Unable to create a shell!", (Throwable)ex2);
        }
    }
    
    boolean hasFlags(final int n) {
        return (this.flags & n) == n;
    }
}
