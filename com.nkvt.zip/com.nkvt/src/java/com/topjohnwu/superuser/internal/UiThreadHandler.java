package com.topjohnwu.superuser.internal;

import com.topjohnwu.superuser.ShellUtils;
import android.os.Looper;
import android.os.Handler;
import java.util.concurrent.Executor;

public class UiThreadHandler
{
    public static final Executor executor;
    public static final Handler handler;
    
    static {
        handler = new Handler(Looper.getMainLooper());
        executor = (Executor)UiThreadHandler$$ExternalSyntheticLambda0.INSTANCE;
    }
    
    public static void run(final Runnable runnable) {
        if (ShellUtils.onMainThread()) {
            runnable.run();
        }
        else {
            UiThreadHandler.handler.post(runnable);
        }
    }
    
    public static void runAndWait(final Runnable runnable) {
        if (ShellUtils.onMainThread()) {
            runnable.run();
        }
        else {
            final WaitRunnable waitRunnable = new WaitRunnable(runnable);
            UiThreadHandler.handler.post((Runnable)waitRunnable);
            waitRunnable.waitUntilDone();
        }
    }
}
