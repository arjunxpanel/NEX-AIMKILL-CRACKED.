package com.topjohnwu.superuser.internal;

import java.util.concurrent.Executor;
import java.util.Iterator;
import java.io.InputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.io.Closeable;
import com.topjohnwu.superuser.Shell;

class JobImpl extends Job implements Closeable
{
    protected List<String> err;
    protected List<String> out;
    protected ShellImpl shell;
    private final List<ShellInputSource> sources;
    private boolean stderrSet;
    
    JobImpl() {
        this.sources = (List<ShellInputSource>)new ArrayList();
        this.stderrSet = false;
    }
    
    JobImpl(final ShellImpl shell) {
        this.sources = (List<ShellInputSource>)new ArrayList();
        this.stderrSet = false;
        this.shell = shell;
    }
    
    private ResultImpl exec0() {
        final boolean b = !this.stderrSet && this.shell.redirect;
        if (b) {
            this.err = this.out;
        }
        final ResultImpl resultImpl = new ResultImpl();
        final List<String> out = this.out;
        List list;
        if (out != null && out == this.err && !Utils.isSynchronized((Collection<?>)out)) {
            list = Collections.synchronizedList((List)this.out);
            resultImpl.out = (List<String>)list;
        }
        else {
            resultImpl.out = this.out;
            list = this.err;
        }
        resultImpl.err = (List<String>)list;
        final List<String> list2 = null;
        List<String> list3 = null;
        final List<String> list4 = null;
        try {
            try {
                this.shell.execTask(new TaskImpl(this.sources, resultImpl));
                this.close();
                resultImpl.out = this.out;
                if (b) {
                    list3 = list4;
                }
                else {
                    list3 = this.err;
                }
                resultImpl.err = list3;
                return resultImpl;
            }
            finally {
                this.close();
                resultImpl.out = this.out;
                if (!b) {
                    list3 = this.err;
                }
                resultImpl.err = list3;
                final ResultImpl shell_ERR = ResultImpl.SHELL_ERR;
                this.close();
                resultImpl.out = this.out;
                iftrue(Label_0223:)(!b);
                final List<String> list5;
                List<String> err = list5;
                while (true) {
                    break Label_0228;
                    List<String> err2 = null;
                    Label_0269: {
                        err2 = this.err;
                    }
                    Label_0274: {
                        break Label_0274;
                        resultImpl.err = err;
                        return shell_ERR;
                        err2 = list2;
                    }
                    resultImpl.err = err2;
                    return;
                    Label_0223:
                    err = this.err;
                    continue;
                }
                final Throwable t;
                Utils.err(t);
                final ResultImpl instance = ResultImpl.INSTANCE;
                this.close();
                resultImpl.out = this.out;
                iftrue(Label_0269:)(!b);
            }
        }
        catch (final IOException ex) {}
    }
    
    @Override
    public Job add(final InputStream inputStream) {
        if (inputStream != null) {
            this.sources.add((Object)new InputStreamSource(inputStream));
        }
        return this;
    }
    
    @Override
    public Job add(final String... array) {
        if (array != null && array.length > 0) {
            this.sources.add((Object)new CommandSource(array));
        }
        return this;
    }
    
    public void close() {
        final Iterator iterator = this.sources.iterator();
        while (iterator.hasNext()) {
            ((ShellInputSource)iterator.next()).close();
        }
    }
    
    @Override
    public Result exec() {
        return this.exec0();
    }
    
    @Override
    public void submit(final Executor executor, final ResultCallback resultCallback) {
        this.shell.executor.execute((Runnable)new JobImpl$$ExternalSyntheticLambda0(this, executor, resultCallback));
    }
    
    @Override
    public Job to(final List<String> out) {
        this.out = out;
        this.err = null;
        this.stderrSet = false;
        return this;
    }
    
    @Override
    public Job to(final List<String> out, final List<String> err) {
        this.out = out;
        this.err = err;
        this.stderrSet = true;
        return this;
    }
}
