package com.api;

import org.json.JSONException;
import org.json.JSONObject;

public class UserData
{
    private String expiry;
    private String subscription;
    private String username;
    
    public UserData(JSONObject jsonObject) throws JSONException {
        jsonObject = jsonObject.getJSONObject("info");
        final JSONObject jsonObject2 = jsonObject.getJSONArray("subscriptions").getJSONObject(0);
        this.username = jsonObject.getString("username");
        this.subscription = jsonObject2.getString("subscription");
        this.expiry = jsonObject2.getString("expiry");
    }
    
    public String getExpiry() {
        return this.expiry;
    }
    
    public String getSubscription() {
        return this.subscription;
    }
    
    public String getUsername() {
        return this.username;
    }
}
