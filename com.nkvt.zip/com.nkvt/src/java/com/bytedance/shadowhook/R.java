package com.bytedance.shadowhook;

public final class R
{
    private R() {
    }
}
