package com.topjohnwu.superuser.internal;

import com.topjohnwu.superuser.Shell;
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.Collection;
import android.util.Log;
import java.nio.charset.StandardCharsets;
import android.os.Build$VERSION;
import android.content.Context;
import java.nio.charset.Charset;

public final class Utils
{
    private static final String TAG = "LIBSU";
    public static final Charset UTF_8;
    public static Context context;
    private static Class<?> synchronizedCollectionClass;
    
    static {
        Charset utf_8;
        if (Build$VERSION.SDK_INT >= 19) {
            utf_8 = StandardCharsets.UTF_8;
        }
        else {
            utf_8 = Charset.forName("UTF-8");
        }
        UTF_8 = utf_8;
    }
    
    public static void err(final String s, final Throwable t) {
        Log.d(s, "", t);
    }
    
    public static void err(final Throwable t) {
        err("LIBSU", t);
    }
    
    public static void ex(final Throwable t) {
        if (vLog()) {
            Log.d("LIBSU", "", t);
        }
    }
    
    public static Context getContext() {
        synchronized (Utils.class) {
            if (Utils.context == null) {
                UiThreadHandler.runAndWait((Runnable)Utils$$ExternalSyntheticLambda0.INSTANCE);
            }
            return Utils.context;
        }
    }
    
    public static Context getDeContext(final Context context) {
        Context deviceProtectedStorageContext = context;
        if (Build$VERSION.SDK_INT >= 24) {
            deviceProtectedStorageContext = context.createDeviceProtectedStorageContext();
        }
        return deviceProtectedStorageContext;
    }
    
    public static boolean isSynchronized(final Collection<?> obj) {
        if (Utils.synchronizedCollectionClass == null) {
            Utils.synchronizedCollectionClass = Collections.synchronizedCollection((Collection)NOPList.getInstance()).getClass();
        }
        return Utils.synchronizedCollectionClass.isInstance(obj);
    }
    
    public static void log(final Object o) {
        log("LIBSU", o);
    }
    
    public static void log(final String s, final Object o) {
        if (vLog()) {
            Log.d(s, o.toString());
        }
    }
    
    public static long pump(final InputStream inputStream, final OutputStream outputStream) throws IOException {
        final byte[] array = new byte[65536];
        long n = 0L;
        while (true) {
            final int read = inputStream.read(array);
            if (read <= 0) {
                break;
            }
            outputStream.write(array, 0, read);
            n += read;
        }
        return n;
    }
    
    public static boolean vLog() {
        return Shell.enableVerboseLogging;
    }
}
