package com.nkvt;

import org.json.JSONException;
import org.json.JSONObject;

public class UserData
{
    private String expiry;
    private String subscription;
    private String username;
    
    public UserData(JSONObject jsonObject) throws JSONException {
        final JSONObject jsonObject2 = jsonObject.getJSONObject("info");
        jsonObject = jsonObject2.getJSONArray("subscriptions").getJSONObject(0);
        this.username = jsonObject2.getString("username");
        this.subscription = jsonObject.getString("subscription");
        this.expiry = jsonObject.getString("expiry");
    }
    
    public String getExpiry() {
        return this.expiry;
    }
    
    public String getSubscription() {
        return this.subscription;
    }
    
    public String getUsername() {
        return this.username;
    }
}
