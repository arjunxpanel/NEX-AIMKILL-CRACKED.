package com.nkvt;

import android.os.Process;
import android.graphics.Paint$Align;
import android.text.StaticLayout;
import android.text.Layout$Alignment;
import java.util.Locale;
import android.os.Build$VERSION;
import android.graphics.Typeface;
import android.graphics.Paint$Style;
import android.text.TextPaint;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.graphics.Shader$TileMode;
import android.graphics.Color;
import android.graphics.PorterDuff$Mode;
import android.graphics.Canvas;
import android.util.AttributeSet;
import java.util.Date;
import android.content.Context;
import android.graphics.Paint;
import android.view.View;

public class DrawView extends View implements Runnable
{
    int FPS;
    Paint mBitMapPaint;
    private Context mContext;
    Paint mFilledPaint;
    Paint mRectPaint1;
    Paint mRectPaint2;
    Paint mStrokePaint;
    Paint mTextPaint;
    Thread mThread;
    long sleepTime;
    Date time;
    
    public DrawView(final Context mContext) {
        super(mContext, (AttributeSet)null, 0);
        this.FPS = 240;
        this.InitializePaints();
        this.setFocusableInTouchMode(false);
        this.setBackgroundColor(0);
        this.time = new Date();
        this.sleepTime = 1000 / this.FPS;
        (this.mThread = new Thread((Runnable)this)).start();
        this.mContext = mContext;
    }
    
    public void ClearCanvas(final Canvas canvas) {
        canvas.drawColor(0, PorterDuff$Mode.CLEAR);
    }
    
    public void DrawCircle(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final float strokeWidth, final float n4, final float n5, final float n6) {
        this.mStrokePaint.setColor(Color.rgb(n, n2, n3));
        this.mStrokePaint.setAlpha(alpha);
        this.mStrokePaint.setStrokeWidth(strokeWidth);
        canvas.drawCircle(n4, n5, n6, this.mStrokePaint);
    }
    
    public void DrawFilledCircle(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final float n4, final float n5, final float n6) {
        this.mFilledPaint.setColor(Color.rgb(n, n2, n3));
        this.mFilledPaint.setAlpha(alpha);
        canvas.drawCircle(n4, n5, n6, this.mFilledPaint);
    }
    
    public void DrawFilledRect(final Canvas canvas, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final float n8) {
        this.mFilledPaint.setColor(Color.rgb(n2, n3, n4));
        this.mFilledPaint.setAlpha(70);
        canvas.drawRect(n5, n6, n5 + n7, n6 + n8, this.mFilledPaint);
    }
    
    public void DrawFilledRectInfo(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final float n4, final float n5, final float n6, final float n7) {
        this.mFilledPaint.setColor(Color.rgb(n, n2, n3));
        this.mFilledPaint.setAlpha(alpha);
        canvas.drawRect(n4, n5, n4 + n6, n5 + n7, this.mFilledPaint);
    }
    
    public void DrawGradientRect(final Canvas canvas, final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final int n8, final float n9, final float n10, final float n11, final float n12) {
        final Paint paint = new Paint();
        paint.setShader((Shader)new LinearGradient(n9, n10, n9 + n11, n10 + n12, Color.argb(n, n2, n3, n4), Color.argb(n5, n6, n7, n8), Shader$TileMode.CLAMP));
        canvas.drawRect(n9, n10, n9 + n11, n10 + n12, paint);
    }
    
    public void DrawLine(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final float strokeWidth, final float n4, final float n5, final float n6, final float n7) {
        this.mStrokePaint.setColor(Color.rgb(n, n2, n3));
        this.mStrokePaint.setAlpha(alpha);
        this.mStrokePaint.setStrokeWidth(strokeWidth);
        canvas.drawLine(n4, n5, n6, n7, this.mStrokePaint);
    }
    
    public void DrawRect(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final int n4, final float n5, final float n6, final float n7, final float n8) {
        this.mStrokePaint.setStrokeWidth((float)n4);
        this.mStrokePaint.setColor(Color.rgb(n, n2, n3));
        this.mStrokePaint.setAlpha(alpha);
        canvas.drawRect(n5, n6, n5 + n7, n6 + n8, this.mStrokePaint);
    }
    
    public void DrawRoundRect(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final float strokeWidth, final int n4, final int n5, final float n6, final float n7, final float n8, final float n9) {
        this.mStrokePaint.setStrokeWidth(strokeWidth);
        this.mStrokePaint.setColor(Color.rgb(n, n2, n3));
        this.mStrokePaint.setAlpha(alpha);
        canvas.drawRoundRect(n6, n7, n6 + n8, n7 + n9, (float)n4, (float)n5, this.mStrokePaint);
    }
    
    public void DrawText(final Canvas canvas, int height, final int n, final int n2, final int n3, float n4, final String s, final float n5, final float n6, final float textSize) {
        try {
            final TextPaint textPaint = new TextPaint();
            textPaint.setColor(Color.argb(height, n, n2, n3));
            try {
                textPaint.setTextSize(textSize);
                textPaint.setAntiAlias(true);
                textPaint.setSubpixelText(true);
                textPaint.setStyle(Paint$Style.FILL);
                textPaint.setTypeface((Typeface)null);
                if (Build$VERSION.SDK_INT >= 21) {
                    textPaint.setElegantTextHeight(true);
                    textPaint.setTextLocale(Locale.forLanguageTag("und"));
                }
                final StaticLayout staticLayout = new StaticLayout((CharSequence)s, textPaint, 10000, Layout$Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
                canvas.save();
                height = staticLayout.getHeight();
                n4 = (float)height;
                try {
                    canvas.translate(n5, n6 - n4);
                    staticLayout.draw(canvas);
                    canvas.restore();
                }
                catch (final Exception ex) {}
            }
            catch (final Exception ex2) {}
        }
        catch (final Exception ex3) {}
    }
    
    public void DrawText2(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final String s, final float n4, final float n5, final float textSize) {
        this.mTextPaint.clearShadowLayer();
        this.mTextPaint.setColor(Color.rgb(n, n2, n3));
        this.mTextPaint.setAlpha(alpha);
        if (this.getRight() <= 1920 && this.getBottom() <= 1920) {
            if (this.getRight() != 1920 && this.getBottom() != 1920) {
                this.mTextPaint.setTextSize(textSize);
            }
            else {
                this.mTextPaint.setTextSize(2.0f + textSize);
                this.mTextPaint.setShadowLayer(12.0f, 0.0f, 0.0f, Color.rgb(n, n2, n3));
            }
        }
        else {
            this.mTextPaint.setShadowLayer(12.0f, 0.0f, 0.0f, Color.rgb(n, n2, n3));
            this.mTextPaint.setTextSize(4.0f + textSize);
        }
        this.mTextPaint.setShadowLayer(12.0f, 0.0f, 0.0f, Color.rgb(n, n2, n3));
        canvas.drawText(s, n4, n5, this.mTextPaint);
    }
    
    public void DrawTextRect(final Canvas canvas, final int alpha, final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int n7, final int n8, final int n9, final int n10, final int n11, final float n12, final float n13) {
        this.mRectPaint1.setColor(Color.rgb(n, n2, n3));
        this.mRectPaint1.setStrokeWidth(1.1f);
        this.mRectPaint1.setAlpha(alpha);
        this.mRectPaint2.setColor(Color.rgb(0, 0, 255));
        this.mRectPaint2.setStrokeWidth(1.1f);
        this.mRectPaint2.setAlpha(150);
        canvas.drawRect(n12 - n4, n13 - n5, n12 + n6, n13 + n7, this.mRectPaint1);
        canvas.drawRect(n12 - n8, n13 - n9, n12 - n10, n13 + n11, this.mRectPaint2);
    }
    
    public void InitializePaints() {
        (this.mStrokePaint = new Paint()).setStyle(Paint$Style.STROKE);
        this.mStrokePaint.setAntiAlias(true);
        (this.mFilledPaint = new Paint()).setStyle(Paint$Style.FILL);
        this.mFilledPaint.setAntiAlias(true);
        (this.mTextPaint = new Paint()).setTypeface(Typeface.MONOSPACE);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setTextAlign(Paint$Align.CENTER);
        (this.mRectPaint1 = new Paint()).setTypeface(Typeface.MONOSPACE);
        this.mRectPaint1.setAntiAlias(true);
        this.mRectPaint1.setTextAlign(Paint$Align.CENTER);
        (this.mRectPaint2 = new Paint()).setTypeface(Typeface.MONOSPACE);
        this.mRectPaint2.setAntiAlias(true);
        this.mRectPaint2.setTextAlign(Paint$Align.CENTER);
        (this.mBitMapPaint = new Paint()).setAntiAlias(true);
    }
    
    protected void onDraw(final Canvas canvas) {
        if (canvas != null && this.getVisibility() == 0) {
            this.ClearCanvas(canvas);
            this.time.setTime(System.currentTimeMillis());
            Menu.OnDrawLoad(this, canvas);
        }
    }
    
    public void run() {
        Process.setThreadPriority(10);
        while (this.mThread.isAlive() && !this.mThread.isInterrupted()) {
            try {
                final long currentTimeMillis = System.currentTimeMillis();
                this.postInvalidate();
                Thread.sleep(Math.max(Math.min(0L, this.sleepTime - (System.currentTimeMillis() - currentTimeMillis)), this.sleepTime));
                continue;
            }
            catch (final InterruptedException ex) {
                return;
            }
            break;
        }
    }
}
