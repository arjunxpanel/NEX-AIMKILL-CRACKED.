package com.topjohnwu.superuser.internal;

import android.os.Parcel;
import android.os.Binder;
import android.content.ComponentName;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.IBinder;
import android.content.Intent;
import android.os.IInterface;

public interface IRootServiceManager extends IInterface
{
    public static final String DESCRIPTOR = "com.topjohnwu.superuser.internal.IRootServiceManager";
    
    IBinder bind(final Intent p0) throws RemoteException;
    
    void broadcast() throws RemoteException;
    
    void connect(final Bundle p0) throws RemoteException;
    
    void setAction(final String p0) throws RemoteException;
    
    void stop(final ComponentName p0) throws RemoteException;
    
    void unbind(final ComponentName p0) throws RemoteException;
    
    public static class Default implements IRootServiceManager
    {
        public IBinder asBinder() {
            return null;
        }
        
        @Override
        public IBinder bind(final Intent intent) throws RemoteException {
            return null;
        }
        
        @Override
        public void broadcast() throws RemoteException {
        }
        
        @Override
        public void connect(final Bundle bundle) throws RemoteException {
        }
        
        @Override
        public void setAction(final String s) throws RemoteException {
        }
        
        @Override
        public void stop(final ComponentName componentName) throws RemoteException {
        }
        
        @Override
        public void unbind(final ComponentName componentName) throws RemoteException {
        }
    }
    
    public abstract static class Stub extends Binder implements IRootServiceManager
    {
        static final int TRANSACTION_bind = 5;
        static final int TRANSACTION_broadcast = 1;
        static final int TRANSACTION_connect = 4;
        static final int TRANSACTION_setAction = 3;
        static final int TRANSACTION_stop = 2;
        static final int TRANSACTION_unbind = 6;
        
        public Stub() {
            this.attachInterface((IInterface)this, "com.topjohnwu.superuser.internal.IRootServiceManager");
        }
        
        public static IRootServiceManager asInterface(final IBinder binder) {
            if (binder == null) {
                return null;
            }
            final IInterface queryLocalInterface = binder.queryLocalInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
            if (queryLocalInterface != null && queryLocalInterface instanceof IRootServiceManager) {
                return (IRootServiceManager)queryLocalInterface;
            }
            return new Proxy(binder);
        }
        
        public static IRootServiceManager getDefaultImpl() {
            return Proxy.sDefaultImpl;
        }
        
        public static boolean setDefaultImpl(final IRootServiceManager sDefaultImpl) {
            if (Proxy.sDefaultImpl != null) {
                throw new IllegalStateException("setDefaultImpl() called twice");
            }
            if (sDefaultImpl != null) {
                Proxy.sDefaultImpl = sDefaultImpl;
                return true;
            }
            return false;
        }
        
        public IBinder asBinder() {
            return (IBinder)this;
        }
        
        public boolean onTransact(final int n, final Parcel parcel, final Parcel parcel2, final int n2) throws RemoteException {
            if (n == 1598968902) {
                parcel2.writeString("com.topjohnwu.superuser.internal.IRootServiceManager");
                return true;
            }
            final Intent intent = null;
            final Bundle bundle = null;
            final ComponentName componentName = null;
            final ComponentName componentName2 = null;
            switch (n) {
                default: {
                    return super.onTransact(n, parcel, parcel2, n2);
                }
                case 6: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    ComponentName componentName3 = componentName2;
                    if (parcel.readInt() != 0) {
                        componentName3 = (ComponentName)ComponentName.CREATOR.createFromParcel(parcel);
                    }
                    this.unbind(componentName3);
                    return true;
                }
                case 5: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    Intent intent2 = intent;
                    if (parcel.readInt() != 0) {
                        intent2 = (Intent)Intent.CREATOR.createFromParcel(parcel);
                    }
                    final IBinder bind = this.bind(intent2);
                    parcel2.writeNoException();
                    parcel2.writeStrongBinder(bind);
                    return true;
                }
                case 4: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    Bundle bundle2 = bundle;
                    if (parcel.readInt() != 0) {
                        bundle2 = (Bundle)Bundle.CREATOR.createFromParcel(parcel);
                    }
                    this.connect(bundle2);
                    return true;
                }
                case 3: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    this.setAction(parcel.readString());
                    return true;
                }
                case 2: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    ComponentName componentName4 = componentName;
                    if (parcel.readInt() != 0) {
                        componentName4 = (ComponentName)ComponentName.CREATOR.createFromParcel(parcel);
                    }
                    this.stop(componentName4);
                    return true;
                }
                case 1: {
                    parcel.enforceInterface("com.topjohnwu.superuser.internal.IRootServiceManager");
                    this.broadcast();
                    return true;
                }
            }
        }
        
        private static class Proxy implements IRootServiceManager
        {
            public static IRootServiceManager sDefaultImpl;
            private IBinder mRemote;
            
            Proxy(final IBinder mRemote) {
                this.mRemote = mRemote;
            }
            
            public IBinder asBinder() {
                return this.mRemote;
            }
            
            @Override
            public IBinder bind(final Intent intent) throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                final Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    if (intent != null) {
                        obtain.writeInt(1);
                        intent.writeToParcel(obtain, 0);
                    }
                    else {
                        obtain.writeInt(0);
                    }
                    IBinder binder;
                    if (!this.mRemote.transact(5, obtain, obtain2, 0) && Stub.getDefaultImpl() != null) {
                        binder = Stub.getDefaultImpl().bind(intent);
                    }
                    else {
                        obtain2.readException();
                        binder = obtain2.readStrongBinder();
                    }
                    obtain2.recycle();
                    obtain.recycle();
                    return binder;
                }
                finally {
                    obtain2.recycle();
                    obtain.recycle();
                    while (true) {}
                }
            }
            
            @Override
            public void broadcast() throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    if (!this.mRemote.transact(1, obtain, (Parcel)null, 1) && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().broadcast();
                    }
                }
                finally {
                    obtain.recycle();
                }
            }
            
            @Override
            public void connect(final Bundle bundle) throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    }
                    else {
                        obtain.writeInt(0);
                    }
                    if (!this.mRemote.transact(4, obtain, (Parcel)null, 1) && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().connect(bundle);
                    }
                }
                finally {
                    obtain.recycle();
                }
            }
            
            public String getInterfaceDescriptor() {
                return "com.topjohnwu.superuser.internal.IRootServiceManager";
            }
            
            @Override
            public void setAction(final String action) throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    obtain.writeString(action);
                    if (!this.mRemote.transact(3, obtain, (Parcel)null, 1) && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().setAction(action);
                    }
                }
                finally {
                    obtain.recycle();
                }
            }
            
            @Override
            public void stop(final ComponentName componentName) throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    if (componentName != null) {
                        obtain.writeInt(1);
                        componentName.writeToParcel(obtain, 0);
                    }
                    else {
                        obtain.writeInt(0);
                    }
                    if (!this.mRemote.transact(2, obtain, (Parcel)null, 1) && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().stop(componentName);
                    }
                }
                finally {
                    obtain.recycle();
                }
            }
            
            @Override
            public void unbind(final ComponentName componentName) throws RemoteException {
                final Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.topjohnwu.superuser.internal.IRootServiceManager");
                    if (componentName != null) {
                        obtain.writeInt(1);
                        componentName.writeToParcel(obtain, 0);
                    }
                    else {
                        obtain.writeInt(0);
                    }
                    if (!this.mRemote.transact(6, obtain, (Parcel)null, 1) && Stub.getDefaultImpl() != null) {
                        Stub.getDefaultImpl().unbind(componentName);
                    }
                }
                finally {
                    obtain.recycle();
                }
            }
        }
    }
}
