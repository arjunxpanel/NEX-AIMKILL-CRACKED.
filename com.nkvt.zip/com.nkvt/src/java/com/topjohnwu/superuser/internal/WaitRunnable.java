package com.topjohnwu.superuser.internal;

public final class WaitRunnable implements Runnable
{
    private Runnable r;
    
    public WaitRunnable(final Runnable r) {
        this.r = r;
    }
    
    public void run() {
        synchronized (this) {
            this.r.run();
            this.r = null;
            this.notifyAll();
        }
    }
    
    public void waitUntilDone() {
        monitorenter(this);
        try {
            while (this.r != null) {
                try {
                    this.wait();
                }
                catch (final InterruptedException ex) {}
            }
            monitorexit(this);
        }
        finally {
            monitorexit(this);
            while (true) {}
        }
    }
}
