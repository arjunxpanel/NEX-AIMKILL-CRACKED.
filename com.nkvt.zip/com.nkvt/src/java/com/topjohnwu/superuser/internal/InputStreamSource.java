package com.topjohnwu.superuser.internal;

import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;

class InputStreamSource implements ShellInputSource
{
    private final InputStream in;
    
    InputStreamSource(final InputStream in) {
        this.in = in;
    }
    
    @Override
    public void close() {
        try {
            this.in.close();
        }
        catch (final IOException ex) {}
    }
    
    @Override
    public void serve(final OutputStream outputStream) throws IOException {
        Utils.pump(this.in, outputStream);
        this.in.close();
        outputStream.write(10);
        Utils.log("SHELL_IN", "<InputStream>");
    }
}
