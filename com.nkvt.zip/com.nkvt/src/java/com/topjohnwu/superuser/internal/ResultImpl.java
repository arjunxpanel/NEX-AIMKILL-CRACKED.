package com.topjohnwu.superuser.internal;

import java.util.Collections;
import java.util.concurrent.Executor;
import java.util.List;
import com.topjohnwu.superuser.Shell;

class ResultImpl extends Result
{
    static ResultImpl INSTANCE;
    static ResultImpl SHELL_ERR;
    int code;
    List<String> err;
    List<String> out;
    
    static {
        ResultImpl.INSTANCE = new ResultImpl();
        ResultImpl.SHELL_ERR = new ResultImpl();
    }
    
    ResultImpl() {
        this.code = -1;
    }
    
    void callback(final Executor executor, final ResultCallback resultCallback) {
        if (resultCallback != null) {
            if (executor == null) {
                resultCallback.onResult(this);
            }
            else {
                executor.execute((Runnable)new ResultImpl$$ExternalSyntheticLambda0(this, resultCallback));
            }
        }
    }
    
    @Override
    public int getCode() {
        return this.code;
    }
    
    @Override
    public List<String> getErr() {
        List list;
        if ((list = this.err) == null) {
            list = Collections.emptyList();
        }
        return (List<String>)list;
    }
    
    @Override
    public List<String> getOut() {
        List list;
        if ((list = this.out) == null) {
            list = Collections.emptyList();
        }
        return (List<String>)list;
    }
}
