package com.topjohnwu.superuser;

public class NoShellException extends RuntimeException
{
    public NoShellException(final String s) {
        super(s);
    }
    
    public NoShellException(final String s, final Throwable t) {
        super(s, t);
    }
}
