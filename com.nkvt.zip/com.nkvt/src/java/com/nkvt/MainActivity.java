package com.nkvt;

import android.app.ActionBar;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.content.Context;
import android.provider.Settings;
import android.os.Build$VERSION;
import android.app.Activity;

public class MainActivity extends Activity
{
    private static final int OVERLAY_PERMISSION_REQUEST_CODE = 100;
    private static final int STORAGE_PERMISSION_REQUEST_CODE = 101;
    
    private void checkOverlayPermission() {
        if (Build$VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays((Context)this)) {
            Toast.makeText((Context)this, (CharSequence)"Overlay permission is required!", 0).show();
            final StringBuilder sb = new StringBuilder();
            sb.append("package:");
            sb.append(this.getPackageName());
            this.startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse(sb.toString())), 100);
            return;
        }
        this.checkStoragePermission();
    }
    
    private void checkStoragePermission() {
        if (Build$VERSION.SDK_INT >= 23 && (this.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0 || this.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0)) {
            Toast.makeText((Context)this, (CharSequence)"Storage permission is required!", 0).show();
            this.requestPermissions(new String[] { "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE" }, 101);
            return;
        }
        this.startLogin();
    }
    
    private void startLogin() {
        new Login((Context)this);
    }
    
    protected void onActivityResult(final int n, final int n2, final Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 100) {
            if (Build$VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays((Context)this)) {
                Toast.makeText((Context)this, (CharSequence)"Overlay permission denied! Exiting...", 0).show();
                this.finish();
            }
            else {
                this.checkStoragePermission();
            }
        }
    }
    
    protected void onCreate(final Bundle bundle) {
        super.onCreate(bundle);
        try {
            Runtime.getRuntime().exec("su");
        }
        catch (final Exception ex) {
            Toast.makeText((Context)this, (CharSequence)"Root not found!", 0).show();
        }
        final ActionBar actionBar = this.getActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        this.checkOverlayPermission();
    }
    
    public void onRequestPermissionsResult(final int n, final String[] array, final int[] array2) {
        super.onRequestPermissionsResult(n, array, array2);
        if (n == 101) {
            if (array2.length > 0 && array2[0] == 0) {
                this.startLogin();
            }
            else {
                Toast.makeText((Context)this, (CharSequence)"Storage permission denied! Exiting...", 0).show();
                this.finish();
            }
        }
    }
}
