package com.nkvt;

import android.widget.Toast;
import android.widget.CompoundButton;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.HttpURLConnection;
import org.json.JSONObject;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings$Secure;
import android.view.View$OnClickListener;
import android.app.Activity;
import android.graphics.PorterDuff$Mode;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.CompoundButton$OnCheckedChangeListener;
import android.widget.Switch;
import android.widget.EditText;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.ViewGroup$LayoutParams;
import android.widget.LinearLayout$LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.content.Context;

public class Login
{
    private static final String API_URL = "https://keyauth.win/api/1.3/";
    private static final String APP_NAME = "Jaatislive468's Application";
    private static final String OWNER_ID = "KAJT2MA4xh";
    private static final String SECRET = "aed84db189e3f8a894f495935558d1630036cad0cd4e338b33c38357e470db6d";
    private static final String VERSION = "1.0";
    private Context context;
    private boolean isDarkMode;
    private ProgressBar loadingBar;
    private TextView loadingText;
    private LinearLayout rootContainer;
    private Utils utils;
    
    public Login(final Context context) {
        this.isDarkMode = false;
        this.context = context;
        this.utils = new Utils(context);
        this.Init();
    }
    
    private void Init() {
        (this.rootContainer = new LinearLayout(this.context)).setOrientation(1);
        this.rootContainer.setGravity(17);
        this.rootContainer.setBackgroundColor(-16777216);
        final LinearLayout linearLayout = new LinearLayout(this.context);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(800, 600));
        linearLayout.setPadding(40, 40, 40, 40);
        final GradientDrawable background = new GradientDrawable();
        background.setColor(-1);
        background.setCornerRadius(40.0f);
        background.setStroke(6, -65536);
        linearLayout.setBackground((Drawable)background);
        linearLayout.setElevation(20.0f);
        linearLayout.setTranslationZ(20.0f);
        final EditText editText = new EditText(this.context);
        final TextView textView = new TextView(this.context);
        final TextView textView2 = new TextView(this.context);
        final LinearLayout linearLayout2 = new LinearLayout(this.context);
        linearLayout2.setOrientation(0);
        linearLayout2.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, -2));
        linearLayout2.setGravity(8388613);
        final Switch switch1 = new Switch(this.context);
        switch1.setTextOn((CharSequence)"\ud83c\udf19");
        switch1.setTextOff((CharSequence)"\u2600\ufe0f");
        switch1.setChecked(false);
        switch1.setText((CharSequence)"");
        switch1.setPadding(0, 0, 0, 10);
        switch1.setOnCheckedChangeListener((CompoundButton$OnCheckedChangeListener)new _$$Lambda$Login$RQAEVdlQGFU1KYlycvS4q_MK1Mc(this, linearLayout, editText, textView, textView2));
        linearLayout2.addView((View)switch1);
        linearLayout.addView((View)linearLayout2);
        textView.setText((CharSequence)"NEX CORPORATION");
        textView.setTextSize(24.0f);
        textView.setTextColor(-65536);
        textView.setTypeface((Typeface)null, 1);
        textView.setShadowLayer(10.0f, 0.0f, 0.0f, -65536);
        textView.setGravity(17);
        linearLayout.addView((View)textView);
        textView2.setText((CharSequence)"NEX CORPORATION | FF MAX OB49");
        textView2.setTextSize(14.0f);
        textView2.setTextColor(-7829368);
        textView2.setGravity(17);
        textView2.setPadding(0, 10, 0, 0);
        linearLayout.addView((View)textView2);
        final View view = new View(this.context);
        view.setLayoutParams((ViewGroup$LayoutParams)new LinearLayout$LayoutParams(-1, 100));
        linearLayout.addView(view);
        editText.setHint((CharSequence)"Enter License Key");
        editText.setTextSize(16.0f);
        editText.setTextColor(-16777216);
        editText.setPadding(30, 25, 30, 25);
        editText.setGravity(17);
        final GradientDrawable background2 = new GradientDrawable();
        background2.setCornerRadius(20.0f);
        background2.setColor(Color.parseColor("#FFECEC"));
        editText.setBackground((Drawable)background2);
        linearLayout.addView((View)editText);
        editText.setText((CharSequence)this.context.getSharedPreferences("NKVTCORPPrefs", 0).getString("saved_license", ""));
        final Button button = new Button(this.context);
        button.setText((CharSequence)"LOGIN");
        button.setTextColor(-1);
        button.setTextSize(18.0f);
        button.setPadding(30, 30, 30, 30);
        final GradientDrawable background3 = new GradientDrawable();
        background3.setColor(-65536);
        background3.setCornerRadius(100.0f);
        background3.setStroke(4, Color.parseColor("#990000"));
        button.setBackground((Drawable)background3);
        final LinearLayout$LayoutParams layoutParams = new LinearLayout$LayoutParams(-1, -2);
        layoutParams.setMargins(0, 40, 0, 10);
        button.setLayoutParams((ViewGroup$LayoutParams)layoutParams);
        linearLayout.addView((View)button);
        final LinearLayout linearLayout3 = new LinearLayout(this.context);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(17);
        linearLayout3.setPadding(0, 10, 0, 10);
        (this.loadingBar = new ProgressBar(this.context)).setVisibility(8);
        this.loadingBar.getIndeterminateDrawable().setColorFilter(-65536, PorterDuff$Mode.SRC_IN);
        (this.loadingText = new TextView(this.context)).setText((CharSequence)"Verifying License");
        this.loadingText.setTextColor(-65536);
        this.loadingText.setTextSize(14.0f);
        this.loadingText.setPadding(20, 0, 0, 0);
        this.loadingText.setVisibility(8);
        linearLayout3.addView((View)this.loadingBar);
        linearLayout3.addView((View)this.loadingText);
        linearLayout.addView((View)linearLayout3);
        final TextView textView3 = new TextView(this.context);
        textView3.setText((CharSequence)"NEX CORPORATION");
        textView3.setTextSize(12.0f);
        textView3.setTextColor(-7829368);
        textView3.setGravity(17);
        textView3.setPadding(0, 20, 0, 0);
        linearLayout.addView((View)textView3);
        this.rootContainer.addView((View)linearLayout);
        ((Activity)this.context).setContentView((View)this.rootContainer);
        button.setOnClickListener((View$OnClickListener)new _$$Lambda$Login$rcAkLK4T_RYk_MhJTijPApkNF0k(this, editText, button));
    }
    
    private String getHWID() {
        return Settings$Secure.getString(this.context.getContentResolver(), "android_id");
    }
    
    private void postError(final String s, final Button button) {
        new Handler(Looper.getMainLooper()).post((Runnable)new _$$Lambda$Login$TKfCucj51li1_uMY6nySdGCXS8w(this, s, button));
    }
    
    private JSONObject sendRequest(String line) throws Exception {
        final HttpURLConnection httpURLConnection = (HttpURLConnection)new URL(line).openConnection();
        httpURLConnection.setRequestMethod("GET");
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(httpURLConnection.getInputStream()));
        final StringBuilder sb = new StringBuilder();
        while (true) {
            line = bufferedReader.readLine();
            if (line == null) {
                break;
            }
            sb.append(line);
        }
        bufferedReader.close();
        return new JSONObject(sb.toString());
    }
    
    private void showToast(final String s) {
        new Handler(Looper.getMainLooper()).post((Runnable)new _$$Lambda$Login$0W2MsUS3jkOqTZbWxqtBXup1__g(this, s));
    }
    
    private void toggleDarkMode(final View view, final EditText editText, final TextView textView, final TextView textView2) {
        final boolean isDarkMode = this.isDarkMode ^ true;
        this.isDarkMode = isDarkMode;
        if (isDarkMode) {
            this.rootContainer.setBackgroundColor(Color.parseColor("#121212"));
            ((GradientDrawable)view.getBackground()).setColor(Color.parseColor("#1E1E1E"));
            editText.setTextColor(-1);
            editText.setHintTextColor(-7829368);
            ((GradientDrawable)editText.getBackground()).setColor(Color.parseColor("#2C2C2C"));
            textView.setTextColor(-65536);
            textView2.setTextColor(-3355444);
        }
        else {
            this.rootContainer.setBackgroundColor(-16777216);
            ((GradientDrawable)view.getBackground()).setColor(-1);
            editText.setTextColor(-16777216);
            editText.setHintTextColor(-12303292);
            ((GradientDrawable)editText.getBackground()).setColor(Color.parseColor("#FFECEC"));
            textView.setTextColor(-65536);
            textView2.setTextColor(-7829368);
        }
    }
}
