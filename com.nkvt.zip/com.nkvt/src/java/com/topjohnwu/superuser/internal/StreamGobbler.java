package com.topjohnwu.superuser.internal;

import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.io.InputStream;
import java.util.concurrent.Callable;

abstract class StreamGobbler<T> implements Callable<T>
{
    private static final String TAG = "SHELLOUT";
    protected final InputStream in;
    protected final List<String> list;
    
    StreamGobbler(final InputStream in, final List<String> list) {
        this.in = in;
        this.list = list;
    }
    
    private boolean outputAndCheck(final String s) {
        if (s == null) {
            return false;
        }
        final int length = s.length();
        final String end_UUID = TaskImpl.END_UUID;
        final int n = length - 36;
        final boolean startsWith = s.startsWith(end_UUID, n);
        String substring = s;
        if (startsWith) {
            if (length == 36) {
                return false;
            }
            substring = s.substring(0, n);
        }
        final List<String> list = this.list;
        if (list != null) {
            list.add((Object)substring);
            Utils.log("SHELLOUT", substring);
        }
        return startsWith ^ true;
    }
    
    protected String process(final boolean b) throws IOException {
        final BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(this.in, Utils.UTF_8));
        while (this.outputAndCheck(bufferedReader.readLine())) {}
        String line;
        if (b) {
            line = bufferedReader.readLine();
        }
        else {
            line = null;
        }
        return line;
    }
    
    static class ERR extends StreamGobbler<Void>
    {
        ERR(final InputStream inputStream, final List<String> list) {
            super(inputStream, list);
        }
        
        public Void call() throws Exception {
            this.process(false);
            return null;
        }
    }
    
    static class OUT extends StreamGobbler<Integer>
    {
        private static final int NO_RESULT_CODE = 1;
        
        OUT(final InputStream inputStream, final List<String> list) {
            super(inputStream, list);
        }
        
        public Integer call() throws Exception {
            int int1 = 1;
            final String process = this.process(true);
            Label_0020: {
                if (process == null) {
                    break Label_0020;
                }
                try {
                    int1 = Integer.parseInt(process);
                    return int1;
                }
                catch (final NumberFormatException ex) {
                    return 1;
                }
            }
        }
    }
}
