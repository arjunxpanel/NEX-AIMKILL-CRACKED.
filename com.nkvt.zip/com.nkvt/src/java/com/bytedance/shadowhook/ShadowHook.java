package com.bytedance.shadowhook;

public final class ShadowHook
{
    private static final int ERRNO_INIT_EXCEPTION = 101;
    private static final int ERRNO_LOAD_LIBRARY_EXCEPTION = 100;
    private static final int ERRNO_OK = 0;
    private static final int ERRNO_PENDING = 1;
    private static final int ERRNO_UNINIT = 2;
    private static final boolean defaultDebuggable = false;
    private static final ILibLoader defaultLibLoader;
    private static final int defaultMode;
    private static final boolean defaultRecordable = false;
    private static long initCostMs = 0L;
    private static int initErrno = 0;
    private static boolean inited = false;
    private static final String libName = "shadowhook";
    private static final int recordItemAll = 1023;
    private static final int recordItemBackupLen = 128;
    private static final int recordItemCallerLibName = 2;
    private static final int recordItemErrno = 256;
    private static final int recordItemLibName = 8;
    private static final int recordItemNewAddr = 64;
    private static final int recordItemOp = 4;
    private static final int recordItemStub = 512;
    private static final int recordItemSymAddr = 32;
    private static final int recordItemSymName = 16;
    private static final int recordItemTimestamp = 1;
    
    static {
        ShadowHook.inited = false;
        ShadowHook.initErrno = 2;
        ShadowHook.initCostMs = -1L;
        defaultLibLoader = null;
        defaultMode = Mode.SHARED.getValue();
    }
    
    public static String getArch() {
        if (isInitedOk()) {
            return nativeGetArch();
        }
        return "unknown";
    }
    
    public static boolean getDebuggable() {
        return isInitedOk() && nativeGetDebuggable();
    }
    
    public static long getInitCostMs() {
        return ShadowHook.initCostMs;
    }
    
    public static int getInitErrno() {
        return ShadowHook.initErrno;
    }
    
    public static Mode getMode() {
        if (isInitedOk()) {
            Mode mode;
            if (Mode.SHARED.getValue() == nativeGetMode()) {
                mode = Mode.SHARED;
            }
            else {
                mode = Mode.UNIQUE;
            }
            return mode;
        }
        return Mode.SHARED;
    }
    
    public static boolean getRecordable() {
        return isInitedOk() && nativeGetRecordable();
    }
    
    public static String getRecords(final RecordItem... array) {
        if (isInitedOk()) {
            int n = 0;
            for (int length = array.length, i = 0; i < length; ++i) {
                switch (ShadowHook$1.$SwitchMap$com$bytedance$shadowhook$ShadowHook$RecordItem[array[i].ordinal()]) {
                    case 10: {
                        n |= 0x200;
                        break;
                    }
                    case 9: {
                        n |= 0x100;
                        break;
                    }
                    case 8: {
                        n |= 0x80;
                        break;
                    }
                    case 7: {
                        n |= 0x40;
                        break;
                    }
                    case 6: {
                        n |= 0x20;
                        break;
                    }
                    case 5: {
                        n |= 0x10;
                        break;
                    }
                    case 4: {
                        n |= 0x8;
                        break;
                    }
                    case 3: {
                        n |= 0x4;
                        break;
                    }
                    case 2: {
                        n |= 0x2;
                        break;
                    }
                    case 1: {
                        n |= 0x1;
                        break;
                    }
                }
            }
            int n2;
            if ((n2 = n) == 0) {
                n2 = 1023;
            }
            return nativeGetRecords(n2);
        }
        return null;
    }
    
    public static String getVersion() {
        return nativeGetVersion();
    }
    
    public static int init() {
        return init(null);
    }
    
    public static int init(final Config config) {
        synchronized (ShadowHook.class) {
            if (ShadowHook.inited) {
                return ShadowHook.initErrno;
            }
            ShadowHook.inited = true;
            final long currentTimeMillis = System.currentTimeMillis();
            Object build;
            if ((build = config) == null) {
                build = new ConfigBuilder().build();
            }
            if (!loadLibrary((Config)build)) {
                ShadowHook.initErrno = 100;
                ShadowHook.initCostMs = System.currentTimeMillis() - currentTimeMillis;
                return ShadowHook.initErrno;
            }
            try {
                ShadowHook.initErrno = nativeInit(((Config)build).getMode(), ((Config)build).getDebuggable());
            }
            finally {
                ShadowHook.initErrno = 101;
            }
            if (((Config)build).getRecordable()) {
                try {
                    nativeSetRecordable(((Config)build).getRecordable());
                }
                finally {
                    ShadowHook.initErrno = 101;
                }
            }
            ShadowHook.initCostMs = System.currentTimeMillis() - currentTimeMillis;
            return ShadowHook.initErrno;
        }
    }
    
    private static boolean isInitedOk() {
        final boolean inited = ShadowHook.inited;
        final boolean b = true;
        boolean b2 = true;
        if (inited) {
            if (ShadowHook.initErrno != 0) {
                b2 = false;
            }
            return b2;
        }
        if (!loadLibrary()) {
            return false;
        }
        try {
            final int nativeGetInitErrno = nativeGetInitErrno();
            if (nativeGetInitErrno != 2) {
                ShadowHook.initErrno = nativeGetInitErrno;
                ShadowHook.inited = true;
            }
            return nativeGetInitErrno == 0 && b;
        }
        finally {
            return false;
        }
    }
    
    private static boolean loadLibrary() {
        return loadLibrary(null);
    }
    
    private static boolean loadLibrary(final Config config) {
        if (config != null) {
            try {
                if (config.getLibLoader() != null) {
                    config.getLibLoader().loadLibrary("shadowhook");
                    return true;
                }
            }
            finally {
                return false;
            }
        }
        System.loadLibrary("shadowhook");
        return true;
    }
    
    private static native String nativeGetArch();
    
    private static native boolean nativeGetDebuggable();
    
    private static native int nativeGetInitErrno();
    
    private static native int nativeGetMode();
    
    private static native boolean nativeGetRecordable();
    
    private static native String nativeGetRecords(final int p0);
    
    private static native String nativeGetVersion();
    
    private static native int nativeInit(final int p0, final boolean p1);
    
    private static native void nativeSetDebuggable(final boolean p0);
    
    private static native void nativeSetRecordable(final boolean p0);
    
    private static native String nativeToErrmsg(final int p0);
    
    public static void setDebuggable(final boolean b) {
        if (isInitedOk()) {
            nativeSetDebuggable(b);
        }
    }
    
    public static void setRecordable(final boolean b) {
        if (isInitedOk()) {
            nativeSetRecordable(b);
        }
    }
    
    public static String toErrmsg(final int n) {
        if (n == 0) {
            return "OK";
        }
        if (n == 1) {
            return "Pending task";
        }
        if (n == 2) {
            return "Not initialized";
        }
        if (n == 100) {
            return "Load libshadowhook.so failed";
        }
        if (n == 101) {
            return "Init exception";
        }
        if (isInitedOk()) {
            return nativeToErrmsg(n);
        }
        return "Unknown";
    }
    
    public static class Config
    {
        private boolean debuggable;
        private ILibLoader libLoader;
        private int mode;
        private boolean recordable;
        
        public boolean getDebuggable() {
            return this.debuggable;
        }
        
        public ILibLoader getLibLoader() {
            return this.libLoader;
        }
        
        public int getMode() {
            return this.mode;
        }
        
        public boolean getRecordable() {
            return this.recordable;
        }
        
        public void setDebuggable(final boolean debuggable) {
            this.debuggable = debuggable;
        }
        
        public void setLibLoader(final ILibLoader libLoader) {
            this.libLoader = libLoader;
        }
        
        public void setMode(final int mode) {
            this.mode = mode;
        }
        
        public void setRecordable(final boolean recordable) {
            this.recordable = recordable;
        }
    }
    
    public static class ConfigBuilder
    {
        private boolean debuggable;
        private ILibLoader libLoader;
        private int mode;
        private boolean recordable;
        
        public ConfigBuilder() {
            this.libLoader = ShadowHook.defaultLibLoader;
            this.mode = ShadowHook.defaultMode;
            this.debuggable = false;
            this.recordable = false;
        }
        
        public Config build() {
            final Config config = new Config();
            config.setLibLoader(this.libLoader);
            config.setMode(this.mode);
            config.setDebuggable(this.debuggable);
            config.setRecordable(this.recordable);
            return config;
        }
        
        public ConfigBuilder setDebuggable(final boolean debuggable) {
            this.debuggable = debuggable;
            return this;
        }
        
        public ConfigBuilder setLibLoader(final ILibLoader libLoader) {
            this.libLoader = libLoader;
            return this;
        }
        
        public ConfigBuilder setMode(final Mode mode) {
            this.mode = mode.getValue();
            return this;
        }
        
        public ConfigBuilder setRecordable(final boolean recordable) {
            this.recordable = recordable;
            return this;
        }
    }
    
    public interface ILibLoader
    {
        void loadLibrary(final String p0);
    }
    
    public enum Mode
    {
        private static final Mode[] $VALUES;
        
        SHARED(0), 
        UNIQUE(1);
        
        private final int value;
        
        private static /* synthetic */ Mode[] $values() {
            return new Mode[] { Mode.SHARED, Mode.UNIQUE };
        }
        
        static {
            $VALUES = $values();
        }
        
        private Mode(final int value) {
            this.value = value;
        }
        
        int getValue() {
            return this.value;
        }
    }
    
    public enum RecordItem
    {
        private static final RecordItem[] $VALUES;
        
        BACKUP_LEN, 
        CALLER_LIB_NAME, 
        ERRNO, 
        LIB_NAME, 
        NEW_ADDR, 
        OP, 
        STUB, 
        SYM_ADDR, 
        SYM_NAME, 
        TIMESTAMP;
        
        private static /* synthetic */ RecordItem[] $values() {
            return new RecordItem[] { RecordItem.TIMESTAMP, RecordItem.CALLER_LIB_NAME, RecordItem.OP, RecordItem.LIB_NAME, RecordItem.SYM_NAME, RecordItem.SYM_ADDR, RecordItem.NEW_ADDR, RecordItem.BACKUP_LEN, RecordItem.ERRNO, RecordItem.STUB };
        }
        
        static {
            $VALUES = $values();
        }
    }
}
