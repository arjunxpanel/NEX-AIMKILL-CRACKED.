package com.topjohnwu.superuser.internal;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Closeable;

interface ShellInputSource extends Closeable
{
    public static final String TAG = "SHELL_IN";
    
    void close();
    
    void serve(final OutputStream p0) throws IOException;
}
