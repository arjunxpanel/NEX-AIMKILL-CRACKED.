package com.topjohnwu.superuser.internal;

import android.os.Message;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.IOException;
import com.topjohnwu.superuser.Shell;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.util.Map$Entry;
import com.topjohnwu.superuser.ShellUtils;
import android.os.Debug;
import android.os.Process;
import java.io.File;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.os.Messenger;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import java.util.UUID;
import android.content.Context;
import android.os.RemoteException;
import android.content.Intent;
import java.util.HashMap;
import android.util.ArrayMap;
import android.os.Build$VERSION;
import android.content.ComponentName;
import java.util.List;
import android.os.IBinder;
import java.util.concurrent.Executor;
import android.util.Pair;
import android.content.ServiceConnection;
import java.util.Map;
import android.os.Handler$Callback;
import android.os.IBinder$DeathRecipient;

public class RootServiceManager implements IBinder$DeathRecipient, Handler$Callback
{
    static final String ACTION_ENV = "LIBSU_BROADCAST_ACTION";
    static final String BUNDLE_BINDER_KEY = "binder";
    static final String BUNDLE_DEBUG_KEY = "debug";
    private static final String INTENT_EXTRA_KEY = "extra.bundle";
    static final String LOGGING_ENV = "LIBSU_VERBOSE_LOGGING";
    private static final String MAIN_CLASSNAME = "com.topjohnwu.superuser.internal.RootServerMain";
    static final int MSG_ACK = 1;
    static final int MSG_STOP = 2;
    static final String TAG = "IPC";
    private static RootServiceManager mInstance;
    private final Map<ServiceConnection, Pair<RemoteService, Executor>> connections;
    private String mAction;
    private IBinder mRemote;
    private IRootServiceManager manager;
    private List<Runnable> pendingTasks;
    private final Map<ComponentName, RemoteService> services;
    
    private RootServiceManager() {
        Object connections;
        if (Build$VERSION.SDK_INT >= 19) {
            this.services = (Map<ComponentName, RemoteService>)new ArrayMap();
            connections = new ArrayMap();
        }
        else {
            this.services = (Map<ComponentName, RemoteService>)new HashMap();
            connections = new HashMap();
        }
        this.connections = (Map<ServiceConnection, Pair<RemoteService, Executor>>)connections;
    }
    
    private boolean bind(final Intent intent, final Executor executor, final ServiceConnection serviceConnection) {
        enforceMainThread();
        final ComponentName enforceIntent = enforceIntent(intent);
        final RemoteService remoteService = (RemoteService)this.services.get((Object)enforceIntent);
        if (remoteService != null) {
            this.connections.put((Object)serviceConnection, (Object)new Pair((Object)remoteService, (Object)executor));
            ++remoteService.refCount;
            executor.execute((Runnable)new RootServiceManager$$ExternalSyntheticLambda3(serviceConnection, enforceIntent, remoteService));
            return true;
        }
        final IRootServiceManager manager = this.manager;
        if (manager == null) {
            return false;
        }
        try {
            final IBinder bind = manager.bind(intent);
            if (bind != null) {
                final RemoteService remoteService2 = new RemoteService(enforceIntent, bind);
                this.connections.put((Object)serviceConnection, (Object)new Pair((Object)remoteService2, (Object)executor));
                this.services.put((Object)enforceIntent, (Object)remoteService2);
                executor.execute((Runnable)new RootServiceManager$$ExternalSyntheticLambda2(serviceConnection, enforceIntent, bind));
            }
            else if (Build$VERSION.SDK_INT >= 28) {
                executor.execute((Runnable)new RootServiceManager$$ExternalSyntheticLambda1(serviceConnection, enforceIntent));
            }
            return true;
        }
        catch (final RemoteException ex) {
            Utils.err("IPC", (Throwable)ex);
            this.manager = null;
            return false;
        }
    }
    
    private Runnable createStartRootProcessTask(final Context context, final String s) {
        Bundle bundle;
        if (this.mAction == null) {
            this.mAction = UUID.randomUUID().toString();
            bundle = new Bundle();
            bundle.putBinder("binder", new Messenger(new Handler(Looper.getMainLooper(), (Handler$Callback)this)).getBinder());
            context.registerReceiver((BroadcastReceiver)new BroadcastReceiver(this, bundle) {
                final RootServiceManager this$0;
                final Bundle val$connectArgs;
                
                public void onReceive(final Context context, final Intent intent) {
                    this.this$0.binderDied();
                    final Bundle bundleExtra = intent.getBundleExtra("extra.bundle");
                    if (bundleExtra == null) {
                        return;
                    }
                    final IBinder binder = bundleExtra.getBinder("binder");
                    if (binder == null) {
                        return;
                    }
                    final IRootServiceManager interface1 = IRootServiceManager.Stub.asInterface(binder);
                    try {
                        binder.linkToDeath((IBinder$DeathRecipient)this.this$0, 0);
                        interface1.connect(this.val$connectArgs);
                        this.this$0.mRemote = binder;
                    }
                    catch (final RemoteException ex) {
                        Utils.err("IPC", (Throwable)ex);
                    }
                }
            }, new IntentFilter(this.mAction));
        }
        else {
            bundle = null;
        }
        final File file = new File(Utils.getDeContext(context).getCacheDir(), "main.jar");
        final StringBuilder sb = new StringBuilder();
        sb.append('(');
        if (Utils.vLog()) {
            sb.append("LIBSU_VERBOSE_LOGGING");
            sb.append("=1 ");
        }
        sb.append("LIBSU_BROADCAST_ACTION");
        sb.append('=');
        sb.append(this.mAction);
        sb.append(" CLASSPATH=");
        sb.append((Object)file);
        sb.append(" /proc/");
        sb.append(Process.myPid());
        sb.append("/exe");
        if (Build$VERSION.SDK_INT >= 27 && Debug.isDebuggerConnected()) {
            if (bundle != null) {
                bundle.putBoolean("debug", true);
            }
            String s2;
            if (Build$VERSION.SDK_INT == 27) {
                s2 = " -Xrunjdwp:transport=dt_android_adb,suspend=n,server=y -Xcompiler-option --debuggable";
            }
            else {
                s2 = " -XjdwpProvider:adbconnection -XjdwpOptions:suspend=n,server=y -Xcompiler-option --debuggable";
            }
            sb.append(s2);
        }
        sb.append(" /system/bin ");
        sb.append(s);
        sb.append(")&");
        return (Runnable)new RootServiceManager$$ExternalSyntheticLambda0(context, file, sb);
    }
    
    private static ComponentName enforceIntent(final Intent intent) {
        final ComponentName component = intent.getComponent();
        if (component == null) {
            throw new IllegalArgumentException("The intent does not have a component set");
        }
        if (component.getPackageName().equals((Object)Utils.getContext().getPackageName())) {
            return component;
        }
        throw new IllegalArgumentException("RootServices outside of the app are not supported");
    }
    
    private static void enforceMainThread() {
        if (ShellUtils.onMainThread()) {
            return;
        }
        throw new IllegalStateException("This method can only be called on the main thread");
    }
    
    static Intent getBroadcastIntent(final Context context, final String s, final IBinder binder) {
        final Bundle bundle = new Bundle();
        bundle.putBinder("binder", binder);
        return new Intent(s).setPackage(context.getPackageName()).addFlags(HiddenAPIs.FLAG_RECEIVER_FROM_SHELL).putExtra("extra.bundle", bundle);
    }
    
    public static RootServiceManager getInstance() {
        if (RootServiceManager.mInstance == null) {
            RootServiceManager.mInstance = new RootServiceManager();
        }
        return RootServiceManager.mInstance;
    }
    
    private boolean stopInternal(final ComponentName componentName) {
        final RemoteService obj = (RemoteService)this.services.remove((Object)componentName);
        if (obj == null) {
            return false;
        }
        final Iterator iterator = this.connections.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            if (((Pair)map$Entry.getValue()).first.equals(obj)) {
                ((Executor)((Pair)map$Entry.getValue()).second).execute((Runnable)new RootServiceManager$$ExternalSyntheticLambda8(map$Entry, componentName));
                iterator.remove();
            }
        }
        return true;
    }
    
    public void binderDied() {
        UiThreadHandler.run((Runnable)new RootServiceManager$$ExternalSyntheticLambda5(this));
    }
    
    public Runnable createBindTask(final Intent intent, final Executor executor, final ServiceConnection serviceConnection) {
        if (!this.bind(intent, executor, serviceConnection)) {
            boolean b;
            if (this.pendingTasks == null) {
                this.pendingTasks = (List<Runnable>)new ArrayList();
                b = true;
            }
            else {
                b = false;
            }
            this.pendingTasks.add((Object)new RootServiceManager$$ExternalSyntheticLambda6(this, intent, executor, serviceConnection));
            if (b) {
                final Context context = Utils.getContext();
                return this.createStartRootProcessTask(context, String.format("--nice-name=%s:root %s %s %s", new Object[] { context.getPackageName(), "com.topjohnwu.superuser.internal.RootServerMain", intent.getComponent().flattenToString().replace((CharSequence)"$", (CharSequence)"\\$"), "start" }));
            }
        }
        return null;
    }
    
    public boolean handleMessage(final Message message) {
        final int what = message.what;
        if (what != 1) {
            if (what == 2) {
                this.stopInternal((ComponentName)message.obj);
            }
        }
        else {
            this.manager = IRootServiceManager.Stub.asInterface(this.mRemote);
            final List<Runnable> pendingTasks = this.pendingTasks;
            this.pendingTasks = null;
            if (pendingTasks != null) {
                final Iterator iterator = pendingTasks.iterator();
                while (iterator.hasNext()) {
                    ((Runnable)iterator.next()).run();
                }
            }
        }
        return false;
    }
    
    public void stop(final Intent intent) {
        enforceMainThread();
        final ComponentName enforceIntent = enforceIntent(intent);
        if (this.manager == null) {
            Shell.EXECUTOR.execute(this.createStartRootProcessTask(Utils.getContext(), String.format("%s %s %s", new Object[] { "com.topjohnwu.superuser.internal.RootServerMain", enforceIntent.flattenToString().replace((CharSequence)"$", (CharSequence)"\\$"), "stop" })));
            return;
        }
        if (!this.stopInternal(enforceIntent)) {
            return;
        }
        try {
            this.manager.stop(enforceIntent);
        }
        catch (final RemoteException ex) {
            Utils.err("IPC", (Throwable)ex);
        }
    }
    
    public void unbind(final ServiceConnection serviceConnection) {
        enforceMainThread();
        if (this.manager == null) {
            return;
        }
        final Pair pair = (Pair)this.connections.remove((Object)serviceConnection);
        if (pair != null) {
            final RemoteService remoteService = (RemoteService)pair.first;
            --remoteService.refCount;
            ((Executor)pair.second).execute((Runnable)new RootServiceManager$$ExternalSyntheticLambda4(serviceConnection, pair));
            if (((RemoteService)pair.first).refCount == 0) {
                this.services.remove((Object)((RemoteService)pair.first).name);
                try {
                    this.manager.unbind(((RemoteService)pair.first).name);
                }
                catch (final RemoteException ex) {
                    Utils.err("IPC", (Throwable)ex);
                }
            }
        }
    }
    
    static class RemoteService
    {
        final IBinder binder;
        final ComponentName name;
        int refCount;
        
        RemoteService(final ComponentName name, final IBinder binder) {
            this.refCount = 1;
            this.name = name;
            this.binder = binder;
        }
    }
}
