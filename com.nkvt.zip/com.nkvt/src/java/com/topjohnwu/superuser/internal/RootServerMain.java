package com.topjohnwu.superuser.internal;

import java.lang.reflect.Constructor;
import android.util.Log;
import android.os.RemoteException;
import android.content.ComponentName;
import android.os.Looper;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.IBinder;
import java.lang.reflect.Method;

class RootServerMain
{
    static final String CMDLINE_START_SERVICE = "start";
    static final String CMDLINE_STOP_SERVICE = "stop";
    static final Method addService;
    static final Method attachBaseContext;
    static final Method getService;
    
    static {
        try {
            final Class<?> forName = Class.forName("android.os.ServiceManager");
            getService = forName.getDeclaredMethod("getService", String.class);
            addService = forName.getDeclaredMethod("addService", String.class, IBinder.class);
            (attachBaseContext = ContextWrapper.class.getDeclaredMethod("attachBaseContext", Context.class)).setAccessible(true);
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
    }
    
    static String getServiceName(final String s) {
        final StringBuilder sb = new StringBuilder();
        sb.append("libsu-");
        sb.append(s);
        return sb.toString();
    }
    
    static Context getSystemContext() {
        try {
            final Class<?> forName = Class.forName("android.app.ActivityThread");
            return (Context)forName.getMethod("getSystemContext", (Class[])new Class[0]).invoke(forName.getMethod("systemMain", (Class[])new Class[0]).invoke((Object)null, new Object[0]), new Object[0]);
        }
        catch (final Exception ex) {
            throw new RuntimeException((Throwable)ex);
        }
    }
    
    public static void main(final String[] array) {
        System.out.close();
        System.err.close();
        if (array.length < 2) {
            System.exit(0);
        }
        Looper.prepareMainLooper();
        final ComponentName unflattenFromString = ComponentName.unflattenFromString(array[0]);
        try {
            final IRootServiceManager interface1 = IRootServiceManager.Stub.asInterface((IBinder)RootServerMain.getService.invoke((Object)null, new Object[] { getServiceName(unflattenFromString.getPackageName()) }));
            if (array[1].equals((Object)"stop")) {
                if (interface1 != null) {
                    try {
                        interface1.setAction(System.getenv("LIBSU_BROADCAST_ACTION"));
                        interface1.stop(unflattenFromString);
                    }
                    catch (final RemoteException ex) {}
                }
                System.exit(0);
            }
            if (interface1 != null) {
                try {
                    interface1.setAction(System.getenv("LIBSU_BROADCAST_ACTION"));
                    interface1.broadcast();
                    System.exit(0);
                }
                catch (final RemoteException ex2) {}
            }
            final Context packageContext = getSystemContext().createPackageContext(unflattenFromString.getPackageName(), 3);
            final Constructor declaredConstructor = packageContext.getClassLoader().loadClass(unflattenFromString.getClassName()).getDeclaredConstructor((Class[])new Class[0]);
            declaredConstructor.setAccessible(true);
            RootServerMain.attachBaseContext.invoke(declaredConstructor.newInstance(new Object[0]), new Object[] { packageContext });
            Looper.loop();
            System.exit(0);
        }
        catch (final Exception ex3) {
            Log.e("IPC", "Error in IPCMain", (Throwable)ex3);
            System.exit(1);
        }
    }
}
