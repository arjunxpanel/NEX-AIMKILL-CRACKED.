package com.topjohnwu.superuser;

import com.topjohnwu.superuser.internal.UiThreadHandler;
import java.util.concurrent.Executor;
import java.util.List;
import java.util.AbstractList;

public abstract class CallbackList<E> extends AbstractList<E>
{
    protected List<E> mBase;
    protected Executor mExecutor;
    
    protected CallbackList() {
        this(UiThreadHandler.executor, null);
    }
    
    protected CallbackList(final List<E> list) {
        this(UiThreadHandler.executor, list);
    }
    
    protected CallbackList(final Executor executor) {
        this(executor, null);
    }
    
    protected CallbackList(final Executor mExecutor, final List<E> mBase) {
        this.mExecutor = mExecutor;
        this.mBase = mBase;
    }
    
    public void add(final int n, final E e) {
        final List<E> mBase = this.mBase;
        if (mBase != null) {
            mBase.add(n, (Object)e);
        }
        this.mExecutor.execute((Runnable)new CallbackList$$ExternalSyntheticLambda0(this, e));
    }
    
    public E get(final int n) {
        final List<E> mBase = this.mBase;
        Object value;
        if (mBase == null) {
            value = null;
        }
        else {
            value = mBase.get(n);
        }
        return (E)value;
    }
    
    public abstract void onAddElement(final E p0);
    
    public E remove(final int n) {
        final List<E> mBase = this.mBase;
        Object remove;
        if (mBase == null) {
            remove = null;
        }
        else {
            remove = mBase.remove(n);
        }
        return (E)remove;
    }
    
    public E set(final int n, final E e) {
        final List<E> mBase = this.mBase;
        Object set;
        if (mBase == null) {
            set = null;
        }
        else {
            set = mBase.set(n, (Object)e);
        }
        return (E)set;
    }
    
    public int size() {
        final List<E> mBase = this.mBase;
        int size;
        if (mBase == null) {
            size = 0;
        }
        else {
            size = mBase.size();
        }
        return size;
    }
}
