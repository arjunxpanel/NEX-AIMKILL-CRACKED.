package com.nkvt;

public final class R
{
    private R() {
    }
    
    public static final class color
    {
        public static final int backgroundColor = 2130771968;
        
        private color() {
        }
    }
    
    public static final class drawable
    {
        public static final int checkbox = 2130837505;
        public static final int ic_launcher_background = 2130837506;
        public static final int ic_launcher_foreground = 2130837507;
        
        private drawable() {
        }
    }
    
    public static final class layout
    {
        public static final int activity_main = 2130903040;
        
        private layout() {
        }
    }
    
    public static final class mipmap
    {
        public static final int ic_launcher = 2130968576;
        public static final int ic_launcher_adaptive_bac1k = 2130968577;
        public static final int ic_launcher_adaptive_back = 2130968578;
        public static final int ic_launcher_adaptive_fore = 2130968579;
        public static final int ic_launcher_round = 2130968580;
        
        private mipmap() {
        }
    }
    
    public static final class string
    {
        public static final int app_name = 2131034112;
        
        private string() {
        }
    }
    
    public static final class style
    {
        public static final int AppTheme = 2131099648;
        
        private style() {
        }
    }
}
