package com.topjohnwu.superuser.internal;

import java.util.AbstractList;

public class NOPList extends AbstractList<String>
{
    private static NOPList list;
    
    private NOPList() {
    }
    
    public static NOPList getInstance() {
        if (NOPList.list == null) {
            NOPList.list = new NOPList();
        }
        return NOPList.list;
    }
    
    public void add(final int n, final String s) {
    }
    
    public String get(final int n) {
        return null;
    }
    
    public String remove(final int n) {
        return null;
    }
    
    public String set(final int n, final String s) {
        return null;
    }
    
    public int size() {
        return 0;
    }
}
