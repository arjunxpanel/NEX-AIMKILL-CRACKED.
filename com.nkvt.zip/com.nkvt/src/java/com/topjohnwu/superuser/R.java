package com.topjohnwu.superuser;

public final class R
{
    private R() {
    }
}
